using System;
using System.Windows.Forms;
using System.Runtime.InteropServices; 
using System.Text; 
using System.IO; 
using System.Collections; //ArrayList
using System.Text.RegularExpressions;


namespace XStrings
{
   
 //-------------------------------------------------
 //�ۤv�g�� TIniFile (�i�Ω����˸m) //2007/06/21-22
 //
 //TIniFile TmpIni = new TIniFile(My.ApplicationIniName());
 //TmpIni.WriteString("sec","key1","test");
 //  
 //TmpIni.Close(); //�g��            

 //TIniFile MYINI = new TIniFile("D:\\DEL\\VAR.INI");
 //string stemp = MYINI.ReadString(textBox1.Text,textBox2.Text, "NONE");
 //MessageBox.Show(stemp);
 //MYINI.Close();
 //-------------------------------------------------
    public class TIniFile
    {
        private string m_Path;
        private TStringList TmpList;
        // IniFile Constructor.
        public TIniFile(string strIniPath)
        {
            m_Path = strIniPath;

            TmpList = new TStringList();
            TmpList.Clear();
            if (File.Exists(m_Path)) TmpList.LoadFromFile(m_Path);
        }
        //~TIniFile()
        public void Close()
        {
            TmpList.SaveToFile(m_Path);
        }
            
            
        public string ReadWriteString(string str_sec, string str_key, string str_default)
        {

            string r = ReadString(str_sec, str_key, str_default);
            WriteString(str_sec, str_key, r);
            return r;
            
        }
        public int ReadWriteInteger(string str_sec, string str_key, int int_default)
        {
            string rr=ReadString(str_sec, str_key, int_default.ToString());
            int r=Convert.ToInt32(rr);  //�� r = int32.Parse(rr);
            WriteString(str_sec, str_key, r.ToString());
            return r; 
        }
        public bool ReadWriteBool(string str_sec, string str_key, bool bool_default)
        {
            string rr;
            bool r=false;
            if (bool_default)
            rr=ReadString(str_sec, str_key, "1");
            else
            rr=ReadString(str_sec, str_key, "0");
             
            if (rr.Trim()=="1") r=true;

            if (r)
            {
                WriteString(str_sec, str_key, "1");
            }
            else
            {
                WriteString(str_sec, str_key, "0");
            }

            return r;
        }

            
        public void UpdateFile()
        {
           TmpList.LoadFromFile(m_Path);  
           TmpList.SaveToFile(m_Path);
        }
        public void DeleteKey(string str_sec, string str_key) 
        {
            int dest_idx;
            dest_idx=FindSec(str_sec);
            if (dest_idx>=0)
            {
                dest_idx=FindKey(str_key,dest_idx);
                if (dest_idx>=0) //�� section �� key
                {
                 TmpList.RemoveAt(dest_idx);
                }
            }
        }
        public Boolean ValueExists(string str_sec, string str_key)
        {
            int dest_idx;
            dest_idx = FindSec(str_sec);
            if (dest_idx >= 0)
            {
                dest_idx = FindKey(str_key, dest_idx);
                if (dest_idx >= 0) //�� section �� key
                {
                    return true;
                }
                else
                    return false;
            }
            else
                return false;
        }

        public Boolean SectionExists(string str_sec)
        {
            int itemp = FindSec(str_sec);
            if (itemp < 0)
                return false;
            else
                return true;
        }


        public void EraseSection(string str_sec)
        {
            int from_idx;
            int dest_idx;
            from_idx=FindSec(str_sec);
            dest_idx=FindSecLastIdx(str_sec);
            if (from_idx >= 0)
            {
                for (int i = from_idx; i <= dest_idx; i++)
                {
                    TmpList.RemoveAt(from_idx);
                }
            }
        }

        public void ClearAll()
        {
            TmpList.Clear();
            TmpList.SaveToFile(m_Path);
        }
        public string ReadSection(string str_sec)
        {
            int from_idx;
            int dest_idx;
            from_idx = FindSec(str_sec) + 1;
            dest_idx = FindSecLastIdx(str_sec);
            StringBuilder sbtemp = new StringBuilder();
            string stemp;
            for (int i = from_idx; i <= dest_idx; i++)
            {
                stemp = TmpList[i].ToString().Trim();
                if ((stemp.Length > 0) && (stemp[0] != ';'))
                    sbtemp.AppendLine(stemp);

            }
            sbtemp.Replace('\r', ' ');
            sbtemp.Replace('\t', ' ');
            return sbtemp.ToString();

        }
        public string ReadCRCSection(string str_sec)
        {
            int from_idx;
            int dest_idx;
            from_idx = FindSec(str_sec) + 1;
            dest_idx = FindSecLastIdx(str_sec);
            StringBuilder sbtemp = new StringBuilder();
            string stemp;
            string stemp1, stemp2;
            for (int i = from_idx; i <= dest_idx; i++)
            {
                stemp = TmpList[i].ToString().Trim();
                if ((stemp.Length > 0) && (stemp[0] != ';') && (stemp.IndexOf("=") >= 0))
                {
                    stemp1 = Txstrings.GetToken(stemp, 1, false, "=").Trim();
                    stemp2 = Txstrings.GetToken(stemp, 2, false, "=").Trim();
                    stemp = stemp1 + "=" + stemp2;
                    sbtemp.AppendLine(stemp);
                }
            }
            return sbtemp.ToString();

        }
        public string ReadSectionValues(string str_sec)
        {
            int from_idx;
            int dest_idx;
            from_idx = FindSec(str_sec) + 1;
            dest_idx = FindSecLastIdx(str_sec);
            StringBuilder sbtemp = new StringBuilder();
            string stemp;
            for (int i = from_idx; i <= dest_idx; i++)
            {
                
                stemp = TmpList[i].ToString().Trim();
                
                if ((stemp.Length > 0) && (stemp[0] != ';'))
                {
                    if (stemp.IndexOf("=") >= 0)
                    {
                        stemp = Txstrings.GetToken(stemp, 2, true, "=").Trim();
                    }
                    if (stemp.Length > 0) 
                        sbtemp.AppendLine(stemp);
                }
            }
            sbtemp.Replace('\r', ' ');
            sbtemp.Replace('\t', ' ');
            return sbtemp.ToString().Trim();

        }
        public int SectionCount(string str_sec)
        {
            int from_idx;
            int dest_idx;
            from_idx = FindSec(str_sec) + 1;
            dest_idx = FindSecLastIdx(str_sec);
            string stemp;
            int icount = 0;
            if (from_idx > 0)
            {
                for (int i = from_idx; i <= dest_idx; i++)
                {
                    stemp = TmpList[i].ToString().Trim();
                    if ((stemp.Length > 3)&& (stemp[0] != ';') )
                        icount = icount + 1; 

                }
            }
            return icount;
       
        }

        public void WriteInteger(string str_sec, string str_key, int int_value)
        {
            WriteString(str_sec, str_key, int_value.ToString());
        }
        public int ReadInteger(string str_sec, string str_key, int int_default)
        {
            UpdateFile();
            string rr=ReadString(str_sec, str_key, int_default.ToString());
            int r=Convert.ToInt32(rr);  //�� r = int32.Parse(rr);
            return r;
        }

        public void WriteDouble(string str_sec, string str_key, Double Double_value)
        {
            WriteString(str_sec, str_key, Double_value.ToString());
        }
        public Double ReadDouble(string str_sec, string str_key, Double Double_default)
        {
            UpdateFile();
            string rr = ReadString(str_sec, str_key, Double_default.ToString());
            Double r = Convert.ToDouble(rr);  //�� r = int32.Parse(rr);
            return r;
        }

        public void WriteBool(string str_sec, string str_key, bool bool_value)
        {
            if (bool_value)
            {
                WriteString(str_sec, str_key, "1");
            }
            else
            {
                WriteString(str_sec, str_key, "0");
            }
        }
        public bool ReadBool(string str_sec, string str_key, bool bool_default)
        {
            UpdateFile();
            string rr;
            bool r=false;
            if (bool_default)
            rr=ReadString(str_sec, str_key, "1");
            else
            rr=ReadString(str_sec, str_key, "0");
            if (rr.Trim()=="1") r=true;
            return r;
        }

        public void WriteString(string str_sec, string str_key, string str_value)
        {
            int dest_idx;
            int tmp_idx;
            dest_idx=FindSec(str_sec);
            //MessageBox.Show(Convert.ToString(dest_idx));
            if (dest_idx>=0)
            {
                dest_idx=FindKey(str_key,dest_idx);
                if (dest_idx>=0) //�� section �� key
                {
                     TmpList[dest_idx] = str_key+"="+str_value;
                     TmpList.SaveToFile(m_Path);
                }
                else //�� section �S key
                {
                     tmp_idx=FindSecLastIdx(str_sec);
                     //TmpList.Insert(tmp_idx,str_key+"="+str_value);
                     if (tmp_idx!=TmpList.Count-1)
                     {
                          TmpList.Insert(tmp_idx+1,str_key+"="+str_value);
                     }
                     else
                     {
                          TmpList.Add(str_key+"="+str_value);
                     }
                }
            }
            else //�S section �S key
            {
                TmpList.Add("["+str_sec+"]");
                TmpList.Add(str_key+"="+str_value);
            }
            TmpList.SaveToFile(m_Path);
        }

        public string ReadString(string str_sec, string str_key, string str_default)
        {
            UpdateFile();
            string r = str_default;
            int dest_idx;
            dest_idx=FindSec(str_sec);
            if (dest_idx>=0)
            {
                dest_idx=FindKey(str_key,dest_idx);
                if (dest_idx>=0) //�� section �� key
                {
                    int ipoint = TmpList[dest_idx].ToString().IndexOf("=")+1;
                    int ilength = TmpList[dest_idx].ToString().Length - ipoint;
                    
                    string stemp = TmpList[dest_idx].ToString().Substring(ipoint, ilength);
                    //r = stemp.Trim();
                    r = stemp;
                }
            }
            return r;
        }
        private int FindSec(string str_sec)
        {
            int r=-1;
            //int icount = 0;
            string stemp;
            stemp = "[" + str_sec + "]";
            string str_sec_label= stemp.ToUpper();
            for (int i=0; i<=TmpList.Count-1; i++)
            {
                stemp=TmpList[i].ToString().ToUpper().Trim();
                stemp= Txstrings.GetToken(stemp,1,false,";").Trim();
                if (stemp == str_sec_label)
                {
                    r = i;
                    break;
                }
            }
            return r;
        }
        private int FindKey(string str_key, int from_idx)
        {
            int r=-1;   //bruce0211
            for (int i=from_idx+1; i<=TmpList.Count-1; i++)
            {
                if(TmpList[i].ToString().Length > 0)
                {
                    if (TmpList[i].ToString().Substring(0,1)=="[") //�J��U�@�Ӹ`��
                    {
                         break;
                    }
                    string[] tmp = TmpList[i].ToString().Split('=');
                    if (tmp[0].ToUpper().Trim() == str_key.ToUpper().Trim())
                    {
                         r=i;
                        break;
                    }                
                }


            }
            return r;
        }
        private int FindSecLastIdx(string str_sec) //���Y�@ section �ϳ̫��m
        {
            int r=-1;  //bruce0211
            int dest_idx=FindSec(str_sec);
            string stemp = "";
            if (dest_idx>=0)
            {
                for (int i=dest_idx+1; i<=TmpList.Count-1; i++)
                {
                    stemp = TmpList[i].ToString().Trim();
                    //if (TmpList[i].ToString().Substring(0, 1) == "[") //�J��U�@�Ӹ`��
                    if (stemp.IndexOf("[") >= 0) //�J��U�@�Ӹ`��
                    {
                          r=i-1;
                          break;
                     }

                }
                if (r==-1) //�S�J��U�@�Ӹ`��
                {
                     r=TmpList.Count-1;
                }
            }
            else
            {
                r=TmpList.Count-1;
            }
            return r;
        }

    }//end for inifile class

//-------------------------------------------------
 //TStringList
 //-------------------------------------------------
 //�ϥΨ�
 //TStringList TmpList = new TStringList();
 //TmpList.Add("bruce");
 //TmpList.Add("bruce 0211");
 //TmpList.SaveToFile("bruce_0211.txt");  
 //
 //TmpList.LoadFromFile("bruce_0211.txt");  
 //for (int i=0; i<=TmpList.Count-1; i++)
 //{
 //  MessageBox.Show(TmpList[i]); 
 //}
 //-------------------------------------------------
    public class TStringList : ArrayList
    {
        //string gstemp[256];
        public void SaveToFile(string fn) 
        {
            StreamWriter sw = File.CreateText(fn);  
            //StreamWriter sw = new StreamWriter(fn, false, System.Text.Encoding.GetEncoding(950)); //�o�ˤ~��g�X����r��

            for(int i = 0; i != this.Count; i++)
            {
                sw.WriteLine(this[i]); 
            }
                  
            sw.Close();
        }
        public void LoadFromFile(string fn) 
        {
            /*
            using (StreamReader sr = new StreamReader("TestFile.txt")) 
            {
            string line;
            // Read and display lines from the file until the end of 
            // the file is reached.
            while ((line = sr.ReadLine()) != null) 
            {
             Console.WriteLine(line);
            }
            }
            */   

            this.Clear();
            /*
            StreamReader sr = new StreamReader(File.OpenRead(fn));
            //�� StreamReader sr = new StreamReader(File.Open(fn, FileMode.Open));
            */
            //�o�ˤ~��Ū�J����r��
            //StreamReader sr = new StreamReader(fn, System.Text.Encoding.GetEncoding(950)); //�� System.Text.Encoding.Default
            StreamReader sr = new StreamReader(fn, System.Text.Encoding.Default);
             
            while (sr.Peek() >= 0) 
            {
                this.Add(sr.ReadLine());    
            }           

            sr.Close();
        }
 
     
    }//end for class

    public class Txstrings
    {
        //���o�����ɸ��| (PATH)
        public static string ApplicationPath()
        {
            string tmp = System.Windows.Forms.Application.StartupPath; 
            //string tmp = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase); //for win ce
            string temp = tmp.Substring(tmp.Length - 1, 1);
            if (temp != "\\")
                tmp = tmp + "\\";

            return tmp;
        }

        public static string AddSlash(string sdata)
        {
            string stemp = sdata.Trim();
            string slast = stemp.Substring(stemp.Length-1, 1);
            if(slast != "\\")
                stemp = stemp+"\\";

            return stemp;
        }

        //���o�����ɧ����ɦW(�t���|)
        public static string ApplicationName()
        {
            return System.Windows.Forms.Application.ExecutablePath;
            //return System.Windows.Forms.Application.StarupPath;
            //return System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase; //for win ce
        }

        //���o�����ɬۦP���|�U�� INI �ɦW(�� TIniFile Create() ����)
        public static string ApplicationIniName()
        {
            //*
            string tmp;
            tmp=System.Windows.Forms.Application.ExecutablePath;
            tmp=tmp.Substring(0,tmp.Length-4)+".ini";
            return tmp;
            //*/

            //for win ce
            //string tmp = ApplicationName();
            //tmp = tmp.Substring(0, tmp.Length - 4) + "_INI.TXT";
            //return tmp;

        }

        //���o�����ɬۦP���|�U�� LOG �ɦW
        public static string ApplicationLogName()
        {
           //*
            string tmp;
            tmp=System.Windows.Forms.Application.ExecutablePath;
            tmp=tmp.Substring(0,tmp.Length-4)+".log";
            return tmp;
            //*/

            //for win ce
            //string tmp = ApplicationName();
            //tmp = tmp.Substring(0, tmp.Length - 4) + "_LOG.txt";
            //return tmp;
        }

        /*********************************************************
            string stemp = Txstrings.ApplicationName();
            MessageBox.Show(stemp);
            stemp = Txstrings.ApplicationIniName();
            MessageBox.Show(stemp);
            stemp = Txstrings.ApplicationPath();
            MessageBox.Show(stemp);
            string stemp = "   -ABCD 1234  aaaa- ";
            stemp = stemp.Trim(' ');
            MessageBox.Show(stemp);
            int itemp = Convert.ToInt32(textBox1.Text); 
            string mytest = Txstrings.GetToken(stemp, itemp, false," " );
            MessageBox.Show(mytest);

            itemp = Txstrings.CountWord(stemp, " ");
            MessageBox.Show(Convert.ToString(itemp));        
         ********************************************************************/

        public static string GetToken(string pData, int index, bool bTrail, string plist)
        {
            int I = 0;
            int W = 0;
            Boolean bInWord = false;
            int head = 1;
            string stemp = pData.Trim();
            int datalength=stemp.Length-1;
            int tail = datalength;
            
            
            
            while ((I <= datalength) && (W <= index))
            {
                if (plist.IndexOf(stemp[I]) >= 0)
                {
                    if ((W == index) && bInWord)
                        tail = I - 1;
                    bInWord = false;
                }
                else
                {
                    if (!bInWord)
                    {
                        bInWord = true;
                        W++;
                        if (W == index)
                            head = I;
                    }
                 }
                I++;

            }//end for while

            if (bTrail)
                tail = datalength;

            if (W >= index)
                stemp = stemp.Substring(head, tail - head + 1);
            else
                stemp = "";


            return stemp;

        }//end for token

  
        public static int CountWord(string pData, string plist)
        {
            string mydata = pData.Trim();
            string[] myArray;
            try
            {
                if (plist.Length == 1)
                {
                    myArray = mydata.Split(new char[] { plist[0] });
                }
                else
                {
                    myArray = Regex.Split(mydata, plist, RegexOptions.IgnoreCase);
                }

                //string[] myArray = Regex.Split(mydata, plist, RegexOptions.IgnoreCase);
                int istart = 0;
                int icount = myArray.Length - 1;
                for (int i = 0; i <= icount; i++)
                {
                    if (myArray[i].Length > 0)
                        istart = istart + 1;
                }
                return istart;
            }
            catch
            {
                return -1;
            }
        }

      
        public static void CopyFile(string fromFile, string toFile)
        {
            string sourceFileName;
            string destFileName;
            sourceFileName = @fromFile;
            destFileName = @toFile;
            FileInfo sourceFile = new System.IO.FileInfo(sourceFileName);
            FileInfo destFile = new System.IO.FileInfo(destFileName);
            try
            {
                if (destFile.Exists) destFile.Delete(); //�p�G�ؼФ��w�s�b�h�R�� 
                sourceFile.CopyTo(destFileName, true); //�N�ӷ����ƻs��ؼФ��  
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            { 
             
            }

        }//end for copy file


    }//end for xstrings class
} //end for name space

 

