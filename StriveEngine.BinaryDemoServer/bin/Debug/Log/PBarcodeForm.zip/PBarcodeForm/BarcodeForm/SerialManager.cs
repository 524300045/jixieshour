﻿using System;
using System.IO.Ports;
using System.Threading;
using System.Text;

class SerialManager
{
	public bool _continue;
	public SerialPort _serialPort = new SerialPort();
	string name = "";
	string message;
	public StringBuilder sbMessage;
	StringComparer stringComparer = StringComparer.OrdinalIgnoreCase;
	Thread readThread;

	public void serialSetup(string PortName, int BaudRate, int DataBits)
	{
		name = PortName;
		_serialPort.PortName = PortName;
		_serialPort.BaudRate = BaudRate;
		_serialPort.DataBits = DataBits;
		_serialPort.Parity = Parity.None;
		_serialPort.StopBits = StopBits.One;
		_serialPort.Handshake = Handshake.None;
		_serialPort.ReadTimeout = 500;
		_serialPort.WriteTimeout = 500;
	}
	public void connect()
	{
		_serialPort.Open();
		_continue = true;
		sbMessage = new StringBuilder();
		readThread = new Thread(new ParameterizedThreadStart(Read));
		readThread.Start(sbMessage);
	}
	public void close()
	{
		_continue = false;
		//readThread.Abort();
		if (null != readThread)
			readThread.Join();
		_serialPort.Close();
	}
	private void Read(object client)
	{
		while (_continue)
		{
			try
			{
				string message = _serialPort.ReadLine();
				this.message = message;
				sbMessage.AppendLine(message);
			}
			//catch (TimeoutException ex)
			//{
			//	if (ex is TimeoutException || ex is System.IO.IOException)
			//		MessageBox.Show(ex.Message);
			//	throw;
			//}
			catch (TimeoutException) { }
			catch (System.IO.IOException) { }
		}
	}
	public void Send(string message)
	{
		_serialPort.WriteLine(String.Format("<{0}>: {1}", _serialPort.PortName, message));
	}
}

