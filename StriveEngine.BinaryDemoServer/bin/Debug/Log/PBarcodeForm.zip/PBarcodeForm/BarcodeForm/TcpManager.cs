﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace BarcodeForm
{
    public class TcpManager
    {
		//此版有1個記錄Debug message的地方(sbDebug)。没有用tb了。要用tb需要由外界在初始時給一個TextBox。
		//此版在外界的TcpProcess中要寫訊息到Control時需調用Invoke(如UpdateUI()中的寫法。
		public TcpClient tcpClient;
        public NetworkStream netStream;
        public Thread tcpHandlerThread;
		public StringBuilder sbDebug;		//Debug message
        public delegate void Del(string message);
		public Del Processes;
		public bool Active = false;

		public void ServerConnect()
        {
            try
            {
                tcpClient = new TcpClient("127.0.0.1", 4000);
                netStream = tcpClient.GetStream();
                tcpHandlerThread = new Thread(new ParameterizedThreadStart(tcpHandler));
				tcpHandlerThread.Name = Processes.Method.Name;
                tcpHandlerThread.Start(tcpClient);
            }
            catch
            {
				sbDebug.AppendLine("ServerConnect:1:server refue!!");
            }
        }
		public void ServerConnect(Del serverProcess, string IP = "127.0.0.1", int port = 4000)
		{
			if (IP == "")
				IP = "127.0.0.1";
			if (port == 0)
				port = 4000;
			try
			{
				sbDebug = new StringBuilder();
				Processes = serverProcess;
				tcpClient = new TcpClient(IP, port);        //需由外界指定。
				netStream = tcpClient.GetStream();
				tcpHandlerThread = new Thread(new ParameterizedThreadStart(tcpHandler));
				tcpHandlerThread.Name = Processes.Method.Name;
				tcpHandlerThread.IsBackground = true;
				tcpHandlerThread.Start(tcpClient);
				sbDebug.AppendLine(tcpClient.Client.LocalEndPoint.ToString());
				sbDebug.AppendLine(tcpClient.Client.RemoteEndPoint.ToString() + "...remote...");
			}
			catch
			{
				sbDebug.AppendLine("ServerConnect:2:server refue!!!");
			}
		}

        public void SeverClose()
        {
            try
            {
                tcpHandlerThread.Abort();
                tcpClient.Close();
                if (netStream != null)
                    netStream.Close();
            }
            catch { }
        }

        public void ServerSend(string message)
        {
            if (tcpClient != null)
            {
                if (tcpClient.Connected)
                {
					byte[] streamBytes = System.Text.ASCIIEncoding.UTF8.GetBytes(message);
                    netStream.Write(streamBytes, 0, streamBytes.Length);
                }
            }
        }
        public void ServerSendLine(string message)
        {
            try
            {
                if (tcpClient.Connected)
                {
                    byte[] streamBytes = System.Text.ASCIIEncoding.UTF8.GetBytes(message + "\r\n");
                    netStream.Write(streamBytes, 0, streamBytes.Length);
                }
            }
            catch
            {
                //no TCP server. do nothing.
            }
        }
        private void tcpHandler(object client)
        {
            try
            {
                byte[] message = new byte[512];
                if (message == null)
                {
                    tcpClient.Close();
                    netStream.Close();
                    return;
                }
                while (Active)
                {
                    Array.Clear(message, 0, 512);
                    if (netStream.Read(message, 0, message.Length) != 0)
					{
						string s = Encoding.ASCII.GetString(message);
						s = s.TrimEnd('\0');      //需要消去字串後的\0。才是正常的字串。
						sbDebug.Append(s);
						Processes(s);
					}
					else
                        break;
                }
            }
            catch
            {
				sbDebug.AppendLine("Disconnected ...tcpHandler...\r\n");
            }
            finally
            {
                tcpClient.Close();
                netStream.Close();
            }
        }

		private void UpdateUI(string s)
		{
			try
			{
				//在外面調用此Class時，需要以下tb方式調用。
				Func<int> del = delegate ()
				{
					//tb.AppendText(s);
					sbDebug.AppendLine(s);
					Processes(s);
					return 0;
				};
				//tb.Invoke(del);
			}
			catch
			{
				//UpdateUI("Something Wrong ...");
			}
		}

		private string UpdateToString(byte[] m)
		{
			StringBuilder currentLine = new StringBuilder();
			int i = 0;
			char c, d;
			for (i = 0; i < m.Length; i++)
			{
				c = (char)m[i];
				if (c == '\r' || c == '\n')
				{
					d = (char)m[i + 1];
					if (d == '\n')
						i++;
					currentLine.Append("\r\n");
				}
				else
					currentLine.Append(c);
			}
			return currentLine.ToString();
		}
	}
}
