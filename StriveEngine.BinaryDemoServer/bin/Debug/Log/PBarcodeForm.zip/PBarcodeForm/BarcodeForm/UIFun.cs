﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using XStrings;
using System.Diagnostics;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.IO;
using System.Text.RegularExpressions;//導入命名空間(正則表達式)
using System.Net.NetworkInformation;
using System.Net;


namespace UIFun
{
 	public class Tcrc
	{
		UInt32[] CRCTable = new UInt32[512];
		const uint CRCPOLY = (uint)0xEDB88320;
		public Tcrc()
		{
			BuildCRCTable();
		}

		private void BuildCRCTable()
		{
			uint i, r;
			for (i = 0; i < 256; i++)
			{
				r = i;
				for (int j = 0; j < 8; j++)
				{	// r= ((r&1)!=0) ? ((r>>1)^CRCPOLY) : (r>>1);
					if ((r & 1) != 0)
						r = (r >> 1) ^ CRCPOLY;
					else
						r >>= 1;
				}
				CRCTable[i] = r;
			}
		}

		public string GetCRC32(string FileName)
		{
			byte[] bytes = File.ReadAllBytes(FileName);
			uint CRC = 0xFFFFFFFF;
			for (int i = 0; i < bytes.Length; i++)
				CRC = RecountCRC(bytes[i], CRC);
			CRC = ~CRC;
			return CRC.ToString("X8");
		}

		public string GetCRC32S(string S)
		{
			uint CRC = 0xFFFFFFFF;
			for (int i = 0; i < S.Length; i++)
				CRC = RecountCRC((byte)S[i], CRC);
			CRC = ~CRC;
			return CRC.ToString("X8");
		}

		private uint RecountCRC(byte b, uint CrcOld)
		{
			return CRCTable[(byte)(CrcOld ^ (uint)b)] ^ ((CrcOld >> 8) & 0x00ffffff);
		}

		public string HextL(Int32 l)
		{
			return l.ToString("X8");
		}
	} //end for tcrc


    public class UIFun
    {
        private struct ConnectionInfo
        {
            public int dwState;
            public int dwLocalAddr;
            public int dwLocalPort;
            public int dwRemoteAddr;
            public int dwRemotePort;
        }

        public static string DOSCMD(string sdata)
        {
            string sname, sarg;
            string stemp = sdata;
            sname = Txstrings.GetToken(stemp, 1, false, " ");
            sarg = Txstrings.GetToken(stemp, 2, true, " ");
            Process process = new Process();
            process.StartInfo.FileName = sname;
            process.StartInfo.Arguments = sarg;
            string result;
            try
            {
                //process.StartInfo.FileName = "adb";
                //process.StartInfo.Arguments = " shell";
                process.StartInfo.CreateNoWindow = true;
                process.StartInfo.RedirectStandardOutput = true;
                process.StartInfo.RedirectStandardInput = true;
                process.StartInfo.RedirectStandardError = true;
                process.StartInfo.UseShellExecute = false;
                process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                process.Start();
                //process.StandardInput.WriteLine("shell");
                //process.StandardInput.WriteLine("su");
                //process.StandardInput.WriteLine("ls");

                //process.StandardInput.WriteLine("exit");
                //process.StandardInput.WriteLine("exit");
                result = process.StandardOutput.ReadToEnd();
                process.WaitForExit();
            }
            catch (Exception exp)
            {
                //MessageBox.Show(exp.Message);
                result = "error";
            }
            return result;
        }

        public static string DOSCMDBat(string sdata)
        {
            string sname, sarg;
            sname = "cmd.exe";
            sarg = "/c " + sdata.Trim();
            Process process = new Process();
            process.StartInfo.FileName = sname;
            process.StartInfo.Arguments = sarg;
            string result;
            try
            {
                //process.StartInfo.FileName = "adb";
                //process.StartInfo.Arguments = " shell";
                process.StartInfo.CreateNoWindow = true;
                process.StartInfo.RedirectStandardOutput = true;
                process.StartInfo.RedirectStandardInput = true;
                process.StartInfo.RedirectStandardError = true;
                process.StartInfo.UseShellExecute = false;
                process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                process.Start();
                //process.StandardInput.WriteLine("shell");
                //process.StandardInput.WriteLine("su");
                //process.StandardInput.WriteLine("ls");
                //process.StandardInput.WriteLine("exit");
                //process.StandardInput.WriteLine("exit");
                result = process.StandardOutput.ReadToEnd().Trim();
                process.WaitForExit();
            }
            catch (Exception exp)
            {
                //MessageBox.Show(exp.Message);
                result = "error";
            }

            if (result.Length > 1)
              return result +"DOSCMD-END"+'\n'; 
            else
                return "DOSCMD-END" ;
        }

        //delete richedit line 0
        public static void DelRTB(RichTextBox rtb)
        {
            int itemp = rtb.Lines.Count();
            if (itemp == 1)
                rtb.Clear();
            else
            {
                rtb.SelectionStart = 0;
                rtb.SelectionLength = rtb.Text.IndexOf("\n", 0) + 1;
                rtb.SelectedText = "";
            }
        }

        //check listbox 取第一字串比對,使用grep為間隔符號
        //因為FindString 只會找到最前面相同的字串就回應了
        public static int ListBoxFindString(ListBox lb, string data, string grep)
        {
            int itemp = lb.FindString(data);
            string stemp;
            if (itemp >= 0)
            {
                stemp = lb.Items[itemp].ToString().Trim().ToUpper();
                stemp = Txstrings.GetToken(stemp, 1, false, grep);
                
                while ((stemp != data.ToUpper()) && (itemp < lb.Items.Count-1) )
                {
                    itemp= itemp+1;
                    stemp = lb.Items[itemp].ToString().Trim().ToUpper();
                    stemp = Txstrings.GetToken(stemp, 1, false, grep);
                }
                if (itemp >= lb.Items.Count)
                    itemp = -1;
            }
            return itemp;
        }

        public static string Time2String(string stype)
        {
            DateTime dt = DateTime.Now;
            string stemp="";
            switch (stype)
            {
                case "ALL":
                    stemp = String.Format("{0:yyyy/MM/dd HH:mm:ss}", dt);
                    break;
                case "TIME":
                    stemp = String.Format("{0:HHmmss}", dt);
                    break;
                case "PATH":
                    stemp = String.Format("{0:yyyyMM}\\{1:dd}\\", dt, dt);
                    break;
                case "FILENAME":
                    stemp = String.Format("{0:HHmmss}.txt", dt);
                    break;
            }
            return stemp;
        }

        public static string HexToChar(string sdata)
        {
            //*
            string stemp = sdata.Trim();
            int itemp = stemp.Length;
            if((itemp % 2) != 0)
                stemp = " "+stemp;

            string sResult = "";
            string stemp1 = "";
            try
            {
                for (int i = 0; i < (stemp.Length - 1); i += 2)
                {
                    stemp1 = stemp.Substring(i, 2).Trim();
                    sResult += (char)Convert.ToInt32(stemp1, 16);
                }
            }
            catch
            {
                sResult = "";
            }
            //*/
            /*
            string HexData = sdata.Trim();
            string[] word = HexData.Split(new char[] { ' ' });
            HexData = string.Join("", word);
            string sResult = "";
            var salmens = new List<string>();
            for (int i = 0; i < (HexData.Length - 1); i += 2)
                salmens.Add(HexData.Substring(i, 2));
            foreach (string s in salmens)
                sResult += (char)Convert.ToInt32(s, 16);
            //*/
            return sResult;
        }

        public static string HexToDec(string sdata)
        {
            string stemp = sdata.ToUpper().Trim();
            try
            {
                stemp = stemp.Replace("0X", "");
                int itemp = Convert.ToInt32(stemp, 16);
                stemp = itemp.ToString();
            }
            catch
            {
                return "-1";
            }
            return stemp;
        }

        public static bool IsNumeric(String strNumber)
        {
            Regex NumberPattern = new Regex("[^0-9.-]");
            return !NumberPattern.IsMatch(strNumber);
        }

        public static bool LanPortInUse(int port)
        {
            bool inUse = false;
            IPGlobalProperties ipProperties = IPGlobalProperties.GetIPGlobalProperties();
            System.Net.IPEndPoint[] ipEndPoints = ipProperties.GetActiveTcpListeners();
            foreach (IPEndPoint endPoint in ipEndPoints)
            {
                if (endPoint.Port == port)
                {
                    inUse = true;
                    break;
                }
            }
            return inUse;
        }

        public static void CloseLanPort(int port)
        {
            //ConnectionInfo[] rows = getTcpTable();
        }
    }//end for UIFun
}
