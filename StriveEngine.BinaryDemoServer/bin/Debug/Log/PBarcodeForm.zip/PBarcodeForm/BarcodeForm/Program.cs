﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BarcodeForm
{
	static class Program
	{
		[DllImport("user32.dll")]
		public static extern int SendMessage(IntPtr hWnd, int wMsg, IntPtr wParam, IntPtr lParam);
		[DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Auto)]
		static extern int RegisterWindowMessage(string lpString);
		public static int _messageId = RegisterWindowMessage("ProgramAlreadyLunch");
		static void checkDoubleProc()
		{
			//取得此process的名稱
			String name = Process.GetCurrentProcess().ProcessName;
			//取得所有與目前process名稱相同的process
			Process[] ps = Process.GetProcessesByName(name);
			//ps.Length > 1 表示此proces已重複執行
			if (ps.Length > 1)
			{
				//int _messageId = RegisterWindowMessage("ProgramAlreadyLunch");
				SendMessage(ps[0].MainWindowHandle, _messageId, IntPtr.Zero, IntPtr.Zero);
				SendMessage(ps[1].MainWindowHandle, _messageId, IntPtr.Zero, IntPtr.Zero);
				System.Environment.Exit(2);
			}
		}

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main()
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			Application.Run(new Form1());
		}
	}
}
