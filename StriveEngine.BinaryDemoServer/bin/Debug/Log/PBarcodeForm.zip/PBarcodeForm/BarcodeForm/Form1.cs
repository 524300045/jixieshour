﻿using StriveEngine;
using StriveEngine.BinaryDemoCore;
using StriveEngine.Tcp.Passive;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using UIFun;
using XStrings;

namespace BarcodeForm
{
	public partial class Form1 : Form
	{
		string gFilePath = "";
		string gcaption = "", gSFISBOM="";
		string gScanCom = "", gsErrorData = "", gBarcode = "", gMACcode = "";
		string gSSNcode = "", gSN2code = "", gMOcode = "", gGuidcode = "";
		Boolean gbChangeini = false, gbSymbolini = false, gbAutoscan = false, gopenerror = false;	//gopenerror，true:開檔ok。false:開檔錯誤。
		Boolean gbTDMode = false, gbFirstOpen = false, gbTimerToHost = false, gbSubmit = false;
		Boolean gbBatchNumber = false;
		TIniFile gCodeini, gChangeini, gSymbolini, gScanini;
		//Timer TimerToHost = new Timer();	//送出字串給Server時，則開啟計算time out。Server需在3分鐘內回應，否則關閉程式。
		TcpManager ClientSocket1, ClientSocket2;
		SerialManager Comm1;
		bool gLooping = false;
		DateTime gdstar, gdEnd;
		int gWhoSendToHost = 0;
		int giCloseTag = 0;
		Tcrc TCRC = new Tcrc();
		uint MSG_SHOW = User32.RegisterWindowMessage("Show Message");
		private delegate void UpdateUICallBackI(int value);
		private delegate void UpdateUICallBackS(string str);
		enum IconType { okbutton = 1, submitbutton = 2, retestbutton = 3, restorebutton = 4 }
		public TcpManager tm = new TcpManager();

		public Form1()
		{
			InitializeComponent();
			FormCreate();
		}

		private void FormCreate()
		{
			//1.獲取和設置當前目錄的完全限定路徑。
			GetFilePath();			//Check product.txt
			labelPath.Text = gFilePath;
			GetCodeIni();			//Check Barcode.ini, update button.Text
			gopenerror = true;
			GetChangeIni();			//Check change.ini
			gbSubmit = true;
			GetSymbolIni();			//Check symbol.ini
			CheckFixtureStatus();   //檢查治具狀態值, get Fixture ID
			if (GetScanIni())		//Check Scan.ini, 設定auto scan使用的com port。若不存在則不用。
				if (gScanini.SectionExists("SCANCOM"))
				{
					gScanCom = gScanini.ReadString("SCANCOM", "SCANCOM", "");
				}
				else
					gScanCom = "";
			//label5.Text = gcaption;
			if (!SetInputForm())	//是否開啟mac與guid的輸入。
			{
				MessageBox.Show("set edit enable error.", "Error");
				gopenerror = false;
			}
			else
				gopenerror = true;
			if (File.Exists(@"c:\usi\mycopy.bat"))
			{
				ProcessStartInfo Info2 = new ProcessStartInfo();
				Info2.FileName = @"c:\usi\mycopy.bat";
				Info2.WorkingDirectory = @"c:\usi\mycopy.bat";
				Process.Start(Info2);	//執行c:\usi\mycopy.bat
			}
			gbFirstOpen = true;
			gbTimerToHost = false;
			SetHostIP();			//設定SFIS的ip，port及thread function.
			gsErrorData = "";
			checkTDtxt(@"c:\TD.txt");
		}

		private void checkTDtxt(string filePath)
		{
			if (File.Exists(filePath))
			{
				gbTDMode = true;
				restoreToolStripMenuItem.Enabled = true;
			}
			else
			{
				gbTDMode = false;
				restoreToolStripMenuItem.Enabled = false;
			}
		}

		private void SetLabelNetText(string str)
		{
			if (InvokeRequired)
			{
				UpdateUICallBackS uu = new UpdateUICallBackS(SetLabelNetText);
				Invoke(uu, str);
			}
			else
				labelNet.Text = str;
		}

		private bool GetCodeIni()       //Barcode.ini
		{
			string str2 = gFilePath + @"\Barcode.ini";
			if (!File.Exists(str2))
			{
				MessageBox.Show("File Barcode.ini does not exists.\r\n" + str2, "Error");
				Application.Exit();
			}
			gCodeini = new TIniFile(str2);
			gcaption = gCodeini.ReadString("control", "FCTCAPTION", "USI FCT TESTER");
			//label5.Text = gcaption;
			try     //建立ICON, 更新按鍵文字
			{
				if (gCodeini.SectionExists("ICON"))
				{
					buttonRetest.Text = gCodeini.ReadString("ICON", "1", "重測");
					buttonSubmit.Text = gCodeini.ReadString("ICON", "2", "測試完成");
					buttonLogout.Text = gCodeini.ReadString("ICON", "3", "使用者登出");
					buttonClose.Text = gCodeini.ReadString("ICON", "4", "結束");
				}
			}
			catch { return false; }
			return true;
		}

		private bool GetChangeIni()     //Change.ini
		{
			string str2 = Directory.GetParent(gFilePath) + @"\change.ini";
			if (File.Exists(str2))
			{
				gChangeini = new TIniFile(str2);
				gbChangeini = true;
			}
			else
			{
				gbChangeini = false;	//没有change.ini檔案，舊的版本，用Barcode.ini存放資料. 
			}
			return true;
		}

		private bool SetInputForm()     //是否使用客戶組態資料
		{
			string str = "";
			try
			{
				//Check control.MACCodeUses
				str = gCodeini.ReadString("control", "MACCodeUses", "OFF").ToUpper();
				if (str.Contains("OFF"))
					textBoxMac.Enabled = false;
				else
					textBoxMac.Enabled = true;
				//Check control.GUIDCodeUses
				//是否要使用 客戶組態的資料。
				str = gCodeini.ReadString("control", "CONFIG", "OFF");
				if (String.Compare(str, "ON", true) == 0)
				{
					bool bUSICheck = false;
					str = gCodeini.ReadString("Position2", "USICHECK", "OFF");
					if (String.Compare(str, "ON", true) == 0)
						bUSICheck = true;
					else
						bUSICheck = false;
					textBoxConfig.Enabled = false;
					textBoxConfig.Visible = true;
					labelConfig.Visible = true;
					//econfig.Enable = false;
					//econfig.Visible = true;
					//lconfig.Visible = true;
					//cbusi.Visible = bUSICheck;
				}
				else
				{
					textBoxConfig.Enabled = false;
					textBoxConfig.Visible = true;
					labelConfig.Visible = true;
					//econfig.Enable = false;
					//econfig.Visible = false;
					//lconfig.Visible = false;
					//cbusi.Visible = false;
					if (gbChangeini)
					{
						gChangeini.DeleteKey("code", "CONFIG");
						gChangeini.DeleteKey("Position2", "CONFIG2");
					}
					else
					{
						gCodeini.DeleteKey("code", "CONFIG");
						gCodeini.DeleteKey("Position2", "CONFIG2");
					}
				}
			}
			catch { return false; }
			return true;
		}

		private void Form1_Activated(object sender, EventArgs e)
		{
			if (gbFirstOpen)
			{
				if (!gopenerror)
					Close();
				gbFirstOpen = false;
			}
			try
			{   //開啟自動掃條碼
				if (gScanCom.Length >= 4)
				{
					if (!(Comm1 == null))
					{
						Comm1 = new SerialManager();
					}
					MessageBox.Show("自動掃條碼，com");
				}
			}
			catch { MessageBox.Show("Open scan com Error."); }
			gdstar = DateTime.MinValue;
		}

		private void SetIconType(int icontype)
		{
			if (InvokeRequired)
			{
				UpdateUICallBackI uu = new UpdateUICallBackI(SetIconType);
				Invoke(uu, icontype);
			}
			else
				SetIconType((IconType)icontype);
		}

		private void SetIconType(IconType icontype)
		{
			switch (icontype)
			{
				case IconType.okbutton:     // IconType.okbutton: 
					if (!buttonOK.Enabled)
					{
						buttonOK.Enabled = true;
						buttonOK.Focus();
						System.Threading.Thread.Sleep(1000);
						/*SetMousePost();	//設定Mouse的位置在ok，submit button的中間*/
					}
					else
					{
						buttonOK.Enabled = false;
						gWhoSendToHost = (int)icontype;
					}
					break;
				case IconType.submitbutton:     // IconType.submit
					if (!buttonSubmit.Enabled)
					{
						restoreToolStripMenuItem.Enabled = true;
						buttonRetest.Enabled = true;
						buttonSubmit.Enabled = true;
						//if (gCodeini.ValueExists("Logfile", "PRINTCOM"))
						//	bbprinter.Enable = true;
						textBoxBarcode.Enabled = true;
						textBoxBarcode.Focus();
					}
					else
					{
						//restoreToolStripMenuItem.Enabled = false;
						buttonRetest.Enabled = false;
						buttonSubmit.Enabled = false;
						//bbprinter.Enabled = false;
						gWhoSendToHost = (int)icontype;
					}
					break;
				case IconType.retestbutton:     // IconType.retest
					buttonRetest.Enabled = false;
					buttonOK.Enabled = false;
					buttonSubmit.Enabled = false;
					//restoreToolStripMenuItem.Enabled = false;
					break;
				case IconType.restorebutton:     // IconType.restore
					if (restoreToolStripMenuItem.Enabled)
					{
						buttonRetest.Enabled = false;
						buttonOK.Enabled = false;
						buttonSubmit.Enabled = false;
						//restoreToolStripMenuItem.Enabled = false;
					}
					else
						restoreToolStripMenuItem.Enabled = true;
					break;
				default:
					buttonRetest.Enabled = false;
					buttonOK.Enabled = false;
					buttonSubmit.Enabled = false;
					//restoreToolStripMenuItem.Enabled = false;
					textBoxBarcode.Focus();
					break;
			}
		}

		private void GetFilePath()      //product.txt
		{
			string str = System.Environment.CurrentDirectory;
			string str2 = str + @"\product.txt";
			//檢查 product.txt 存在, product.txt中第一行為路徑，最後一個字元是"\"。
			if (!File.Exists(str2))
			{
				MessageBox.Show("File product.txt not exist.\r\n" + str2, "File not exist.\r\n");
				Application.Exit();
			}
			using (StreamReader sr = new StreamReader(str2))
			{
				gFilePath = sr.ReadLine();
			}
			//textBox5.AppendText(gFilePath);
			if ('\\' == gFilePath[gFilePath.Length - 1])
				gFilePath = gFilePath.Substring(0, gFilePath.Length - 1);
		}

		private bool GetSymbolIni()     //Symbol.ini
		{
			//string codePath, sTemp;
			string str = System.Environment.CurrentDirectory;
			string str2 = Directory.GetParent(gFilePath) + @"\Symbol.ini";
			if (gbChangeini)            //Symbol.ini預設路徑在~\prod\Symbol.ini，可以在change.ini中改變路徑。
			{
				if (gChangeini.SectionExists("SYMBOL"))
					str2 = gChangeini.ReadString("SYMBOL", "PATH", str2);
			}
			if (!File.Exists(str2))
			{   //設定了路徑，檔案就應該要存在。否則就不應設定路徑。
				MessageBox.Show("File does not exists.\r\n" + str2, "Error");
				Application.Exit();
			}
			gSymbolini = new TIniFile(str2);
			gbSymbolini = true;
			return true;
		}   //GetSymbol.ini

		private bool CheckFixtureStatus()
		{
			labelFixtureID.Text = "";
			if (gSymbolini == null)
				Application.Exit();
			try
			{
				if (gSymbolini.SectionExists("FixtureID"))
				{
					string str = gSymbolini.ReadString("FixtureID", "IDHead", "") +
						gSymbolini.ReadString("FixtureID", "IDNumber", "");
					if (str.Length == 0)
						labelID.Text = "Temp Error"; // Unetfun.GetLocalName;
					else
						labelFixtureID.Text = str;
						//labelID.Text = "ID: " + str;
				}
				if (gSymbolini.SectionExists("DeviceCheck"))
				{
					//self.lMAX.Visible:= true;
					//self.lCounter.Visible:= true;
					//if self.DeviceCheck  then;
					gbSymbolini = true;
				}
				else
					gbSymbolini = false;
			}
			catch { Application.Exit(); }
			return true;
		}

		private bool GetScanIni()       //Scan.ini
		{
			string str = System.Environment.CurrentDirectory;
			string str2 = str + @"\prod\Scan.ini";
			if (!File.Exists(str2))
			{
				//MessageBox.Show("File Scan.ini does not exists.\r\n" + str2, "Error");
				return false;
			}
			try
			{
				gScanini = new TIniFile(str2);
				gbAutoscan = false;
			}
			catch { return false; }
			return true;
		}

		private void SetHostIP()
		{
			int port = 0;
			string host = "";
			if (gbChangeini)
			{
				ClientSocket1 = new TcpManager();
				port = gChangeini.ReadInteger("host", "port", 1024);
				host = gChangeini.ReadString("host", "IPAddress", "127.0.0.1");
				ClientSocket1.Active = true;
				ClientSocket1.ServerConnect(Client1, host, port);
				//ClientSocket2.Port:= self.gchangeini.ReadInteger('host', 'port', 1024);
				//Clientsocket2.Host:= self.gchangeini.ReadString('host', 'IPAddress', '127.0.0.1');
				//MessageBox.Show("Change.ini " + host + ": " + port);
			}
			else
			{
				ClientSocket1 = new TcpManager();
				port = gCodeini.ReadInteger("host", "port", 1024);
				host = gCodeini.ReadString("host", "IPAddress", "127.0.0.1");
				ClientSocket1.ServerConnect(Client2, host, port);
			}
		}

		private void Client1(string message)
		{
			if (rDTestToolStripMenuItem.Checked)
				MessageBox.Show("Client1: " + message, "Client1");
			ClientSocket1Read(message);
			//HostDataProcess(message);
		}

		private void ClientSocket1Read(string message)
		{
			string stemp;
			stemp = message;
			if (rDTestToolStripMenuItem.Checked)
				MessageBox.Show("Get data from host.\r\n" + stemp, "Socket Read");
			ClientSocket1.Active = false;		//已經收到Server回應，停掉client thread。
			//if (rDTestToolStripMenuItem.Checked)
			//	MessageBox.Show("Get data from host.2.", "RDTest");
			if (HostDataProcess(stemp))
			{   //Host回傳資料正確
				//if send barcode to host no error then Enable below button
				if (gWhoSendToHost == (int)IconType.okbutton)
				{
					if (!OpenMainForm())
					{
						MessageBox.Show("open PUSIGB.exe Error.");
						//lableNet.Text = "Please check PUSIGB.exe location";
						SetLabelNetText("Please check PUSIGB.exe location.");
						//復原成未送bar code to host前的狀態
						SetIconType(IconType.okbutton);
						return;
					}
					System.Threading.Thread.Sleep(2000);
					//timerFind.Enabled = true;
					//SetIconType(2);     // (IconType.submitbutton);
					buttonSubmit_Click(null, null);
				}
				else
					SetIconType(0);
			}
			else
			{   //回傳資料不正確
				if (gWhoSendToHost == (int)IconType.okbutton)
				{
					//復原成未送bar code to host前的狀態
					if (!buttonOK.Enabled)
						SetIconType(1);     //IconType.okbutton
				}
				else if ((!buttonSubmit.Enabled) && (gSubmitNumber < 3))    //設定成submit to host前的狀態
					SetIconType(2);     //(IconType.submitbutton);
				else
					SetIconType(0);		//((IconType)0);
			}   //end for hostprocess
				//清除wait host respond time out & socket
			timerToHost.Enabled = false;	//Server已回應，不必time out了。
			//TimerToHost.Tag = 0;
			gbTimerToHost = false;
			//ClientSocket1.Active = false;	//已經取得Server的回應了。Server回到等待狀態。
		}

		private bool HostDataProcess(string data)
		{
			string stemp, sbom;
			int myitemp;    //用來控制傳回的資料是否有意義
			bool result = false;
			stemp = data.ToUpper();
			myitemp = 0;
			if (stemp.Contains("OK1"))
				myitemp = 1;
			if (stemp.Contains("FAIL1"))
				myitemp = 2;
			if (stemp.Contains("OK2"))
				myitemp = 3;
			if (stemp.Contains("FAIL2"))
				myitemp = 4;
			//不顯示中文的Image
			//image1.Picture.LoadFromFile(GetCurrentDir()+@"\empty.bmp");
			//pictureBox1.Image = new Bitmap(Environment.CurrentDirectory + @"\empty.bmp");
			SetLabelNetText("Client1: " + stemp);
			switch (myitemp)
			{
				case 1:		//OK1
					if (gWhoSendToHost == myitemp)
					{
						//labelNet.Text = stemp;
						result = true;
						//labelNet.Text = "Testing:" + stemp;
						//SetIconType(IconType.submitbutton);
					}
					else
					{
						//labelNet.Text = "SFC Error Data: " + stemp;
						result = false;
					}
					break;
				case 2:		//FAIL1
					if (gWhoSendToHost ==(myitemp - 1))
					{
						result = false;
						//labelNet.Text = "Fail1:" + stemp;
						//SetIconType(IconType.restorebutton);
					}
					else
					{
						//labelNet.Text = "SFC Error Data: " + stemp;
						result = false;
					}
					break;
				case 3:		//OK2
					if (gWhoSendToHost == (myitemp - 1))
					{
						result = true;
						gSubmitNumber = 0;
						SetIconType((IconType)0);
						ClearInputData();
						EmptyBarcode();
						//labelNet.Text = "Key In next barcode.";
						Cursor = Cursors.Default;
					}
					else
					{
						//labelNet.Text = "SFC Error Data: " + stemp;
						result = false;
					}
					break;
				case 4:		//FAIL2
					if (gWhoSendToHost == (myitemp - 2))
					{
						result = false;
						//labelNet.Text = "Fail2: " + stemp;
						gSubmitNumber = gSubmitNumber + 1;
					}
					else
					{
						//labelNet.Text = "SFC Error Data: " + stemp;
						result = false;
					}
					break;
				default:
					//labelNet.Text = "SFC--Return data is Error: " + stemp;
					result = false;
					break;
			}
			return result;
		}

		private void ClearInputData()
		{
			textBoxConfig.Text = "";
			textBoxBarcode.Text = "";
			textBoxMac.Text = "";
			textBoxGuid.Text = "";
		}

		private void Client2(string message)
		{
			MessageBox.Show("Client2: " + message, "Client2");
		}

		protected override void WndProc(ref Message m)
		{
			if (m.Msg == Program._messageId)
			{
				tm.ServerConnect(TcpProcess1, "127.0.0.1", 4000);
				tm.ServerSendLine(getIPAddress());
				tm.sbDebug = new StringBuilder();
				//if (textBox1.Lines.Length > 1300)           //當textBox中文字太多時刪掉，避免影響處理速度。
				//	textBox1.Clear();
			}
			base.WndProc(ref m);
		}

		private void textBoxBarcode_KeyUp(object sender, KeyEventArgs e)
		{
			int ikey, itemp, ilength;
			string sBarcode2, sConfig2;
			if (e.KeyValue == 13)
			{
				itemp = gCodeini.ReadInteger("control", "BarcodeLength", 0);
				ilength = textBoxBarcode.Text.Length;
				if (itemp != ilength)
				{	//檢查輸入的條碼長度(ilength)符合預期(itemp)
					textBoxBarcode.Text = "";
					return;
				}
				gdEnd = DateTime.Now;
				TimeSpan ts = gdEnd - gdstar;
				if (!gbTDMode)
				{
					if (ts.Seconds > 1)
					{
						textBoxBarcode.Text = "";
						gdstar = DateTime.Now;
						return;
					}
				}
				gdstar = DateTime.Now;
				//檢查Barcode是否指到正確目錄。怎樣是指到正確目錄？
				if (!CheckBarcode(textBoxBarcode.Text, true))
				{
					if (!gbBatchNumber)
					{
						MessageBox.Show("Barcode data Error.");
						OpenVersionForm();
						buttonClose_Click(sender, null);
						Close();
					}
					else
					{
						textBoxBarcode.Focus();
						return;
					}
				}
				if (textBoxConfig.Visible)
				{
					textBoxConfig.Text = GetConfigData(textBoxBarcode.Text).Trim();
					if (textBoxConfig.Text.Length == 0)
					{
						MessageBox.Show("Config data Error.");
						textBoxBarcode.Text = "";
						textBoxBarcode.Focus();
						return;
					}
					if (gbChangeini)
						gChangeini.WriteString("code", "CONFIG", textBoxConfig.Text);
					else
						gCodeini.WriteString("code", "CONFIG", textBoxConfig.Text);
					if (!textBoxMac.Enabled)
					{   //只有textBoxMac.Enabled為false才需要判斷
						if (SetConfgMAC(textBoxConfig.Text))
							textBoxMac.Enabled = true;
						else
						{
							textBoxMac.Enabled = false;
							if (gbChangeini)
								gChangeini.WriteString("code", "MAC", "");
							else
								gCodeini.WriteString("code", "MAC", "");
						}
					}
					//加上USI的os，Version的變更資料。
					if (false)      //(cbusi.Checked)
					{
					}
					else
					{   //如果没有做check的動作則主動刪除這個key。
						if (gbChangeini)
							gChangeini.DeleteKey("Position", "CONFIG2");
						else
							gCodeini.DeleteKey("Position", "CONFIG2");
					}
				}   //if (textBoxConfig.Visible)
				textBoxBarcode.Enabled = false;
				//設定三分鐘計時關閉
				giCloseTag = 0;
				timerClose.Enabled = true;
				if (gbChangeini)
					gChangeini.WriteString("code", "Barcode", textBoxBarcode.Text);
				else
					gCodeini.WriteString("code", "Barcode", textBoxBarcode.Text);
				//檢查長度
				if (textBoxMac.Enabled)
				{
					textBoxMac.Focus();
					//如果有多個MAC需要輸入，在此做初始動作。
					textBoxMac.Tag = 1;
					if (gbChangeini)
						gChangeini.EraseSection("MultiMAC");
					else
						gCodeini.EraseSection("MultiMAC");
				}
				else
				{
					if (textBoxGuid.Enabled)
						textBoxGuid.Focus();
					else
					{
						if (!buttonOK.Enabled)
						{
							SetIconType(IconType.okbutton);     //okbutton
							buttonOK_Click(null, null);
						}
					}
				}
				textBoxBarcode.Enabled = true;
			}   //if (e.KeyValue == 13)
			gdstar = DateTime.Now;
		}

		private bool SetConfgMAC(string sConfig)
		{
			string stemp, svar, start, sbit;
			int iLength, iLoop, iCount;
			bool result = false;
			try
			{
				if (sConfig.Length < 1)
					return (false);
				listBox2.Items.Clear();
				string listbox2items = gCodeini.ReadSection("Config");
				iCount = listBox2.Items.Count;
				for (iLoop = 0; iLoop < iCount; iLoop++)
				{
					stemp = gCodeini.ReadString("Config", iLoop.ToString(), "-1");
					if (stemp == "-1")
						return (false);
					svar = Txstrings.GetToken(stemp, 1, false, "").ToUpper();
					start = Txstrings.GetToken(stemp, 2, false, "");
					sbit = Txstrings.GetToken(stemp, 3, false, "");
					if (svar == "LAN")
					{
						stemp = sConfig.Substring(int.Parse(start), int.Parse(sbit));
						if (stemp != "0")
						{
							result = true;
							return (result);
						}
					}
				}   //end of for-loop
				listBox2.Items.Clear();
			}
			catch { }
			return (result);
		}
		
		private string GetConfigData(string Barcode)
		{
			string codePath, stemp, mycode, SFIS, sAdd;
			TIniFile AConfigini;
			int iCount, iloop, iStart, iLength;
			string result = "";
			codePath = gFilePath;
			iCount = Txstrings.CountWord(codePath, @"\");
			stemp = Txstrings.GetToken(codePath, 1, false, @"\");
			//決定systembom.ini的路徑。Ubarcode.pas中較複雜，這裡先簡單指定。
			stemp = codePath + @"\..\systembom.ini";
			if (!File.Exists(stemp))
			{
				MessageBox.Show("File not Exist: " + stemp);
				return (result);
			}
			try
			{
				AConfigini = new TIniFile(stemp);
				//在這加入判斷是否由SFISBOM來取得BOM的資料。
				SFIS = AConfigini.ReadString("control", "SFISBOM", "OFF");
				if (SFIS == "ON")
				{
					if (SendBarcodeToHost(Barcode))
					{
						Cursor = Cursors.WaitCursor;
						try
						{
							iCount = 0;
							while ((iCount < 20) && (gSFISBOM.Length == 0))
							{
								Application.DoEvents();
								iCount = iCount + 1;
								System.Threading.Thread.Sleep(1000);
							}
						}
						finally { Cursor = Cursors.Default; }
						if (gSFISBOM == "ERROR")
							gSFISBOM = "";
					}
					else
					{   //連不上server
						MessageBox.Show("Link SFIS Server Error.");
						gSFISBOM = "";
					}
				}   //end of SFIS=="ON"
				else
				{   //SFIS=="OFF"
					iStart = gCodeini.ReadInteger("Position", "START", 1);
					iLength = gCodeini.ReadInteger("Position", "LENGTH", 1);
					mycode = Barcode.Substring(iStart, iLength);
					stemp = "";
					stemp = AConfigini.ReadString("CONFIG", mycode, "");
				}
			}
			catch { return (result); }
			//加入USI的資料所要的判斷。
			mycode = gCodeini.ReadString("Position", "USIADD", "OFF").Trim();
			if (mycode == "ON")
				stemp = AddConfig(stemp);
			else
			{
				DelConfig();
				iCount = gCodeini.ReadInteger("control", "configlength", 0);
				iCount = iCount - stemp.Length;
				//補足不夠的長度。
				sAdd = "";
				if (iCount > 0)
				{
					for (iloop = 0; iloop < iCount; iloop++)
						sAdd = sAdd + "0";
				}
				stemp = stemp + sAdd;
			}
			//判斷是否要把MAC的視窗打開。
			return (stemp);
		}

		private string GetConfigData2(string sBarcode2)
		{
			string codePath, stemp, myCode;
			TIniFile aConfigini;
			int iCount, iloop, iStart, iLength;
			string result = "";
			codePath = gFilePath;
			//決定systemBOM2.ini的路徑。
			stemp = gFilePath + @"\systembom2.ini";
			if (!File.Exists(stemp))
			{
				MessageBox.Show("File not Exists: " + stemp);
				return (result);
			}
			try
			{
				aConfigini = new TIniFile(stemp);
				iStart = gCodeini.ReadInteger("Position2", "START", 1);
				iLength = gCodeini.ReadInteger("Position2", "LENGTH", 1);
				myCode = sBarcode2.Substring(iStart, iLength);
				stemp = aConfigini.ReadString("CONFIG", myCode, "");
			}
			catch { return (result); }
			//要加入USI的資料所要的判斷
			myCode = gCodeini.ReadString("Position2", "USIADD2", "OFF").Trim();
			if (myCode == "ON")
				stemp = AddConfig2(stemp, sBarcode2);
			else
				DelConfig2();
			return (stemp);
		}

		private bool DelConfig()
		{
			string stemp, sAddName;
			int iLoop, iCount, iPoint;
			bool bStartAdd, bExist;
			//清空listbox2用來裝資料USIADD
			listBox2.Items.Clear();
			string listbox2Items = gCodeini.ReadSectionValues("USIADD");
			iPoint = listBox2.Items.Count;
			//清空listbox2用來裝資料Conifg
			listBox2.Items.Clear();
			listbox2Items = gCodeini.ReadSectionValues("Config");
			//將USIADD section的資料由config section中刪除
			bStartAdd = false;
			while (bStartAdd == false)
			{
				//由USIADD來判斷結束與否
				stemp = gCodeini.ReadString("USIADD", iPoint.ToString(), "");
				if (stemp.Length < 1)
					bStartAdd = false;
				else
				{
					//取出要刪除的資料
					sAddName = Txstrings.GetToken(stemp, 1, false, "");
					//取出最後的資料
					iCount = listBox2.Items.Count;
					//判斷是否要刪除config section 中的資料和listbox2中的
					bExist = false;
					if (listBox2.Items.Contains(sAddName))
					{
						for (iLoop = iCount - 1; iLoop > 0; iLoop--)
						{
							stemp = listBox2.Items.ToString();  //Items.Strings[iLoop]
							stemp = Txstrings.GetToken(stemp, 2, true, "=");
							stemp = Txstrings.GetToken(stemp, 1, false, "");
							//判斷存在不存在其中
							if (stemp == sAddName)
							{
								bExist = true;
								iCount = iLoop;
								break;
							}
						}   //end of for-loop
						if (bExist)
						{
							listBox2.Items.Remove(iCount);
							gCodeini.DeleteKey("Config", (iCount + 1).ToString());
						}
					}
					iPoint = iPoint - 1;
				}
			}
			listBox2.Items.Clear();
			return true;
		}   //DelConfig()

		private bool DelConfig2()
		{
			string stemp, sAddName;
			int iLoop, iCount, iPoint;
			bool bStartAdd, bExist;
			//清空listbox2用來裝資料USIADD
			listBox2.Items.Clear();
			string listbox2Items = gCodeini.ReadSectionValues("USIADD2");
			iPoint = listBox2.Items.Count;
			//清空listbox2用來裝資料Config
			listBox2.Items.Clear();
			listbox2Items = gCodeini.ReadSectionValues("Config2");
			//將USIADD section的資料由config section中刪除
			bStartAdd = true;
			while (bStartAdd)
			{
				//由USIADD來判斷結束與否，由最後一個往前讀取，一直到iPoint=0為止
				stemp = gCodeini.ReadString("USIADD2", iPoint.ToString(), "");
				if (stemp.Length < 1)
					bStartAdd = false;
				else
				{
					//取出要刪除的資料
					sAddName = Txstrings.GetToken(stemp, 1, false, "");
					//取出最後的資料
					iCount = listBox2.Items.Count;
					//判斷是否要刪除config section中的資料和listbox2中的
					bExist = false;
					if (listBox2.Items.Contains(sAddName))
					{
						for (iLoop = iCount - 1; iLoop >= 0; iLoop--)
						{
							stemp = listBox2.Items[iLoop].ToString();
							stemp = Txstrings.GetToken(stemp, 2, true, "=");
							stemp = Txstrings.GetToken(stemp, 1, false, "");
							//判斷存在不存在其中
							if (stemp == sAddName)
							{
								bExist = true;
								iCount = iLoop;
								break;
							}
						}   //end of for-loop
						if (bExist)
						{
							listBox2.Items.RemoveAt(iCount);
							gCodeini.DeleteKey("Config2", (iCount + 1).ToString());
						}
					}
				}
				iPoint = iPoint - 1;
			}   //end of while
			listBox2.Items.Clear();
			return (true);
		}   //DelConfig2()

		private void helpToolStripMenuItem_Click(object sender, EventArgs e)
		{
			string stemp;
			stemp = "Ver：" +
				FileVersionInfo.GetVersionInfo(System.Reflection.Assembly.GetExecutingAssembly().Location).FileVersion.ToString();
			labelNet.Text = stemp;
		}

		private string AddConfig(string sConfig)
		{
			string stemp, sAddTemp, sAddName;
			int iAddStart, iAddBit, iEndStart, iEndBit;
			int iLoop, iCount = 0, iPoint;
			bool bStartAdd, bExists, bFirstAdd;
			string result = sConfig;
			//清空listbox2用來裝資料
			listBox2.Items.Clear();
			string listBoxItems = gCodeini.ReadSectionValues("Config");
			//將USIADD Section的資料加config section中。
			bStartAdd = true;
			iPoint = 1;
			sAddTemp = "";
			while (bStartAdd == false)
			{
				//由USIADD來判斷結束與否
				stemp = gCodeini.ReadString("USIADD", iPoint.ToString(), "");
				if (stemp.Length < 1)
					bStartAdd = false;
				else
				{
					//取出要加入的資料
					sAddName = Txstrings.GetToken(stemp, 1, false, "").Trim();
					iAddStart = int.Parse(Txstrings.GetToken(stemp, 2, false, ""));
					iAddBit = int.Parse(Txstrings.GetToken(stemp, 3, false, ""));
					//取出最後的資料
					//iCount = listBoxItems.Count;
					//stemp = gCodeini.ReadString("Config", iCount.ToString(), "");
					if (stemp.Length < 1)
						return (result);
					else
					{
						iEndStart = int.Parse(Txstrings.GetToken(stemp, 2, false, ""));
						iEndBit = int.Parse(Txstrings.GetToken(stemp, 3, false, ""));
					}   //end of length<1
						//加入Barcode資料
					stemp = textBoxBarcode.Text.Substring(iAddStart, iAddBit);
					sAddTemp = sAddTemp + stemp;
					//判斷是否要加到config section
					bExists = false;
					if (listBoxItems.Contains(sAddName))
					{
						//存在才進入另一層判斷。
						for (iLoop = iCount - 1; iLoop > 0; iLoop--)
						{
							//stemp = listBoxItems[iLoop];
							stemp = Txstrings.GetToken(stemp, 2, true, "=");
							stemp = Txstrings.GetToken(stemp, 1, false, "");
							//判斷存在不存在其中
							if (stemp == sAddName)
							{
								bExists = true;
								break;
							}
						}   //end of for loop
					}   //end of contain()
					if (!bExists)
					{
						if (iPoint != 1)
							iEndStart = iEndStart + iEndBit;
						else
							iEndBit = gCodeini.ReadInteger("control", "configlength", 0) + 1;
						sAddName = "   " + sAddName + "   " + iEndStart.ToString() + "   " + iAddBit.ToString();
						gCodeini.WriteString("config", (iCount + 1).ToString(), sAddName);
						//listBoxItems.append((iCount + 1).ToString() + "=" + sAddName);
					}
				}//end of if length<1
				iPoint = iPoint + 1;
			}   //end of while
			listBox2.Items.Clear();
			iCount = gCodeini.ReadInteger("control", "configlength", 0);
			iCount = iCount - sConfig.Length;
			//補足不夠的長度
			stemp = "";
			if (iCount > 0)
				for (iLoop = 1; iLoop < iCount; iLoop++)
					stemp = stemp + "0";
			result = sConfig + stemp + sAddTemp;
			return (result);
		}   //AddConfig()

		private string AddConfig2(string sConfig, string Barcode2)
		{
			string stemp, sAddTemp, sAddName;
			int iAddStart, iAddBit, iEndStart, iEndBit;
			int iLoop, iCount = 0, iPoint;
			bool bStartAdd, bExists, bFirstAdd;
			string result = sConfig;
			//清空listbox2用來裝資料
			listBox2.Items.Clear();
			string listBoxItems = gCodeini.ReadSectionValues("Config");
			//將USIADD Section的資料加config section中。
			bStartAdd = true;
			iPoint = 1;
			sAddTemp = "";
			while (bStartAdd == false)
			{
				//由USIADD來判斷結束與否
				stemp = gCodeini.ReadString("USIADD", iPoint.ToString(), "");
				if (stemp.Length < 1)
					bStartAdd = false;
				else
				{
					//取出要加入的資料
					sAddName = Txstrings.GetToken(stemp, 1, false, "").Trim();
					iAddStart = int.Parse(Txstrings.GetToken(stemp, 2, false, ""));
					iAddBit = int.Parse(Txstrings.GetToken(stemp, 3, false, ""));
					//取出最後的資料
					//iCount = listBoxItems.Count;
					//stemp = gCodeini.ReadString("Config", iCount.ToString(), "");
					if (stemp.Length < 1)
						return (result);
					else
					{
						iEndStart = int.Parse(Txstrings.GetToken(stemp, 2, false, ""));
						iEndBit = int.Parse(Txstrings.GetToken(stemp, 3, false, ""));
					}   //end of length<1
						//加入Barcode資料
					stemp = textBoxBarcode.Text.Substring(iAddStart, iAddBit);
					sAddTemp = sAddTemp + stemp;
					//判斷是否要加到config section
					bExists = false;
					if (listBoxItems.Contains(sAddName))
					{
						//存在才進入另一層判斷。
						for (iLoop = iCount - 1; iLoop > 0; iLoop--)
						{
							//stemp = listBoxItems[iLoop];
							stemp = Txstrings.GetToken(stemp, 2, true, "=");
							stemp = Txstrings.GetToken(stemp, 1, false, "");
							//判斷存在不存在其中
							if (stemp == sAddName)
							{
								bExists = true;
								break;
							}
						}   //end of for loop
					}   //end of contain()
					if (!bExists)
					{

						iEndStart = iEndStart + iEndBit;
						sAddName = "   " + sAddName + "   " + iEndStart.ToString() + "   " + iAddBit.ToString();
						gCodeini.WriteString("config", (iCount + 1).ToString(), sAddName);
						//listBoxItems.append((iCount + 1).ToString() + "=" + sAddName);
					}
				}//end of if length<1
				iPoint = iPoint + 1;    //指到下一筆。
			}   //end of while
			listBox2.Items.Clear();
			result = sConfig + sAddTemp;
			return (result);
		}   //AddConfig2()

		private bool SendBarcodeToHost(string sbarcode)
		{
			bool result = false;
			MemoryStream ms;
			string sdata;
			int icount;
			if (!ClientSocket2.tcpClient.Connected)
				ClientSocket2.tcpClient.Connect("localhost", 5000);     //未完成。
			icount = 0;
			while ((!ClientSocket2.tcpClient.Connected) && (icount < 10))
			{
				Application.DoEvents();       //Application.ProcessMessages()
				icount += 1;
				System.Threading.Thread.Sleep(1000);
			}
			gSFISBOM = "";
			if (icount > 10)
				return result;
			else
			{
				sdata = "DUMMY," + sbarcode +
					",0,DUMMY,DUMMY,,OK,CUST_MODEL=??? CUST_PN=??? NEXT_GROUP=??? PROJECT_NAME=???";
				//image1.LoadFromFile(gFilePath + @"\wait.bmp");
				byte[] msgByte = Encoding.Default.GetBytes(sdata);
				ClientSocket2.netStream.Write(msgByte, 0, msgByte.Length);  //ClientSocket2.tcpClient.SendText(sdata);
			}
			return true;
		}

		private void OpenVersionForm()
		{
			string RunPath, stemp;
			Process APHandle = null;
			RunPath = Environment.CurrentDirectory;			//Environment.CommandLine;
			RunPath = RunPath + @"\Productver.exe";
			try
			{
				this.WindowState = FormWindowState.Minimized;
				APHandle = Process.Start(RunPath);
				this.WindowState = FormWindowState.Normal;
			}
			catch
			{
				MessageBox.Show("Run PUSIGB error: " + RunPath);
				return;
			}
		}

		private bool CheckBarcode(string barcode, bool ChangePath)
		{
			bool result = false;
			string sPath, stemp, sVersion, sIniFile, sProductfile;
			string sQC, sNewVersion, sCheckData;
			TIniFile myVerIni;
			//List<string> mylist;
			//TStringList mylist;
			int iloop, icount, ilength, istart;
			System.IO.StreamReader filever;
			//File filever;
			string myBatchNumber;
			sPath = Environment.CurrentDirectory;   //沒有結尾的"\"	//取出目前檔案路徑。
			sProductfile = sPath + @"\product.txt"; //product.txt: 第1行是專案路徑。第2行是QC mode
			filever = new StreamReader(sProductfile);
			stemp = filever.ReadLine(); //product.txt: 第1行是專案路徑。第2行是QC mode
			sQC = filever.ReadLine();
			sProductfile = stemp;
			filever.Close();
			//由Product.txt中的資料來取得產品別。如果檔案不存在則不用判斷barcode。
			icount = Txstrings.CountWord(stemp, @"\");
			sVersion = sPath + @"\prod\" + Txstrings.GetToken(sProductfile, icount - 1, false, @"\") + @"\version.ini";	//目標路徑的上一層目錄。
			if (!File.Exists(sVersion))
				return true;
			//開啟version.ini來取得資料。
			myVerIni = new TIniFile(sVersion);
			//mylist = new TStringList();
			string[] mylist;
			try
			{
				ilength = myVerIni.ReadInteger("number", "CheckLength", 0);
				istart = myVerIni.ReadInteger("number", "START", 1);
				if (ilength == 0)
				{
					MessageBox.Show("Get version.ini CheckLength Error.");
					return false;
				}
				sCheckData = barcode.Trim();
				sCheckData = sCheckData.Substring(istart-1, ilength).ToUpper();
				//檢查是否同一批資料，配合version.ini的資料來處理
				gbBatchNumber = true;       //是否要回去product version的程式。
				if (gbChangeini)
				{   //gbChangeini=true, 新版存在於change.ini。
					if (gChangeini.ValueExists("number", "BatchNumber"))
					{
						myBatchNumber = gChangeini.ReadString("number", "BatchNumber", "000");
						myBatchNumber = myBatchNumber.Trim('\t');
						if (myBatchNumber != sCheckData)
						{
							gbBatchNumber = false;
							MessageBox.Show("Batch number Error.");
							return false;
						}
					}
				}
				else
				{   //gbChangeini=false, 舊版存在於version.ini
					if (myVerIni.ValueExists("number", "BatchNumber"))
					{
						myBatchNumber = myVerIni.ReadString("number", "BatchNumber", "000").Trim();
						if (myBatchNumber != sCheckData)
						{
							gbBatchNumber = false;
							MessageBox.Show("Batch number Error2.");
							return false;
						}
					}
				}
				//檢查是否是同一批資料，配合version.ini的資料來處。
				sVersion = Txstrings.GetToken(sProductfile, icount, false, @"\");
				sQC = sQC.Trim().ToUpper();
				//由version.ini取得的資料含名 1=abcd,efgh,ksjf
				stemp = myVerIni.ReadSectionValues("barcode");
				//mylist = myVerIni.ReadSectionValues("barcode");
				mylist = stemp.Split(new char[] { '\n','\r'});
				//判斷barcode check資料存在mylist中
				if (!stemp.Contains(sCheckData))
				{
					MessageBox.Show("The barcode type not in Version.ini");
					return false;
				}
				string[] mylist2;
				try
				{
					for (iloop = 0; iloop < mylist.Length; iloop++)
					{   //按順序檢查barcode 是否相等
						//;      barcode     QC    PathName   Explain
						//4 =    09103100     N    DVT-QC     VISTA-LTE   AT&T   ANT-INT   RF   Test
						stemp = mylist[iloop];
						mylist2 = stemp.Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
						//stemp = mylist.List(iloop);
						//判斷QC資料是否相等
						//判斷Version path對不對
						if (sCheckData == mylist2[0])
							if (sQC == mylist2[1])
								if (sVersion == mylist2[2])
								{
									result = true;
									break;
								}
					}   //for loop
					//判斷是否要更改product.txt
					if (ChangePath)
					{
						icount = Txstrings.CountWord(sProductfile, "\\");
						sProductfile = sPath + @"\prod\" + Txstrings.GetToken(sProductfile, icount-1, false, "\\") + "\\" + sVersion + "\\";
						stemp = sPath + @"\product.txt";
						try
						{
							StreamWriter filever1;
							filever1 = new StreamWriter(stemp);
							filever1.WriteLine(sProductfile);
							filever1.WriteLine(sQC);
							filever1.Close();
						}
						catch(Exception ex) { MessageBox.Show("Error: changePath , product.txt" + ex.Message); }
						if (rDTestToolStripMenuItem.Checked)
							MessageBox.Show("File path will be change to: " + sProductfile);
						GetFilePath();
						if (GetCodeIni())
						{
							stemp = textBoxBarcode.Text;
							textBoxBarcode.Text = stemp;
							result = true;
						}
						else
							result = false;
					}
				}
				catch { MessageBox.Show("Find data Error"); return false; }
			}
			catch { }
			//mylist.free;
			myVerIni.Close();
			return result;
		}

		private void textBoxBarcode_Leave(object sender, EventArgs e)
		{   //TFBarcode.EBarcodeExit()
			int itemp, ilength;
			//gdstar = DateTime.MinValue;
			if (textBoxMac.Focused || buttonOK.Focused || textBoxGuid.Focused)
			{
				itemp = gCodeini.ReadInteger("control", "BarcodeLength", 0);
				ilength = textBoxBarcode.Text.Length;
				if (buttonClose.Focused)
					return;
				if (itemp != ilength)
				{
					SetLabelNetText("barcode number length Error.");
					//MessageBox.Show("barcode number length Error.");
					EmptyBarcode();
					textBoxBarcode.Text = "";
					textBoxBarcode.Focus();
				}
			}
		}

		private void EmptyBarcode()
		{
			string stemp = "";
			int itemp = 0;
			int iloop = 0;
			const string mydata = "Exit";
			if (!File.Exists(gFilePath + @"\barcode.ini"))
			{
				MessageBox.Show("File not found: " + gFilePath + @"\barcode.ini");
				return;
			}
			//empty barcode
			itemp = gCodeini.ReadInteger("control", "BarcodeLength", 20);
			stemp = "";
			for (iloop = 0; iloop <= itemp / 4; iloop++)
				stemp = stemp + mydata;
			stemp = stemp.Substring(0, itemp);
			if (gbChangeini)
				gChangeini.WriteString("code", "Barcode", stemp);
			else
				gCodeini.WriteString("code", "Barcode", stemp);
			//empty mac code
			itemp = gCodeini.ReadInteger("control", "MACCodeLength", 20);
			stemp = "";
			for (iloop = 0; iloop <= itemp / 4; iloop++)
				stemp = stemp + mydata;
			stemp = stemp.Substring(0, itemp);
			if (gbChangeini)
				gChangeini.WriteString("code", "MAC", stemp);
			else
				gCodeini.WriteString("code", "MAC", stemp);
			//empty guid code
			itemp = gCodeini.ReadInteger("control", "GUIDCodeLength", 20);
			stemp = "";
			for (iloop = 0; iloop <= itemp / 4; iloop++)
				stemp = stemp + mydata;
			stemp = stemp.Substring(0, itemp);
			if (gbChangeini)
				gChangeini.WriteString("code", "GUID", stemp);
			else
				gCodeini.WriteString("code", "GUID", stemp);
			//
			gBarcode = "";
			gMACcode = "";
			gGuidcode = "";
			gSSNcode = "";
			gSN2code = "";
			gMOcode = "";
		}

		public void Debug(string s)
		{
			Func<int> del = delegate ()
			{
				labelID.Text = s;
				return 0;
			};
			labelID.Invoke(del);
		}

		//處理PUSIGB的指令及參數
		public void TcpProcess1(string message)
		{
			//System.Byte[] atmp = Encoding.ASCII.GetBytes(message);
			//if (message[0] == '1')
			//	return;
			string s1 = message;  // Encoding.UTF8.GetString(message);
			string s2 = s1 + "haha";
			tm.ServerSend(s2);
			Debug(s2);
			tm.ServerSend(s2);
			Debug(s2);
			tm.ServerSend(s2);
			Debug(s2);
		}

		//處理PUSIGB的指令及參數
		/*		public void TcpProcess(string message)
				{
					//System.Byte[] atmp =  message; 
					if (message[0] == '1')
						return;
					tm.ServerSend(message);
					label7.Text = message;
					//Pxstrings pa = new Pxstrings(message);
					//int i = 0;
					//int tmp = 0;
					//string par1 = "", par2 = "";
					//while (i < pa.GetCount())
					//{
					//	int oval = 0;
					//	CameraControlFlags bflag = CameraControlFlags.Manual;
					//	switch (pa.GetToken(i).ToUpper())
					//	{
					//		case "BARCODE":
					//			par1 = pa.GetToken(++i);
					//			Global.sn = par1;
					//			labelBarcode.Text = par1;
					//			break;
					//		case "BLUE":
					//			par1 = pa.GetToken(++i);
					//			par2 = pa.GetToken(++i);
					//			Range.blueD = int.Parse(par1);
					//			Range.blueU = int.Parse(par2);
					//			if (Range.blueD > Range.blueU)
					//			{
					//				tmp = Range.blueD;
					//				Range.blueD = Range.blueU;
					//				Range.blueU = tmp;
					//			}
					//			iniSetup.WriteValue("BLUERANGE", "CommandLine", string.Format("{0},{1}", par1, par2));
					//			labelBlue.Text = par1 + " ~ " + par2;
					//			break;
					//		case "CONNECT":
					//			tm.ServerConnect(textBox1, TcpProcess);
					//			tm.ServerSendLine(Global.connectMessage);
					//			break;
					//		case "DISCONNECTED":
					//			cmdDisconnected();
					//			return;
					//		case "EXPOSURE":     //Exposure, Focus, Zoom三者參數馬上設定，不存到ini中。
					//			par1 = pa.GetToken(++i);
					//			Global.exposure = int.Parse(par1);
					//			//iniTDVision.WriteValue("Exposure", "", par1);
					//			//iniSetup.WriteValue("EXPOSURE", "CommandLine", string.Format("{0}", par1));
					//			oval = int.Parse(par1);
					//			webCap._camControl.Set(CameraControlProperty.Exposure, oval, bflag);
					//			webCap.setInternal(KSProperties.CameraControlFeature.KSPROPERTY_CAMERACONTROL_EXPOSURE, oval);
					//			break;
					//		case "FOCUS":       //Exposure, Focus, Zoom三者參數馬上設定，不存到ini中。
					//			par1 = pa.GetToken(++i);
					//			Global.focus = int.Parse(par1);
					//			//iniTDVision.WriteValue("Focus", "", par1);
					//			//iniSetup.WriteValue("FOCUS", "CommandLine", string.Format("{0}", par1));
					//			oval = int.Parse(par1);
					//			webCap._camControl.Set(CameraControlProperty.Focus, oval, bflag);
					//			webCap.setInternal(KSProperties.CameraControlFeature.KSPROPERTY_CAMERACONTROL_FOCUS, oval);
					//			break;
					//		case "GREEN":
					//			par1 = pa.GetToken(++i);
					//			par2 = pa.GetToken(++i);
					//			Range.greenD = int.Parse(par1);
					//			Range.greenU = int.Parse(par2);
					//			if (Range.greenD > Range.greenU)
					//			{
					//				tmp = Range.greenD;
					//				Range.greenD = Range.greenU;
					//				Range.greenU = tmp;
					//			}
					//			iniSetup.WriteValue("GREENRANGE", "CommandLine", string.Format("{0},{1}", par1, par2));
					//			labelGreen.Text = par1 + " ~ " + par2;
					//			break;
					//		case "LEDNUM":
					//			par1 = pa.GetToken(++i);
					//			Global.LedNum = int.Parse(par1);
					//			labelLEDNum.Text = par1;
					//			break;
					//		case "LEVEL":       //gray
					//			par1 = pa.GetToken(++i);
					//			par2 = pa.GetToken(++i);
					//			Range.grayD = int.Parse(par1);
					//			Range.grayU = int.Parse(par2);
					//			labelLevel.Text = par1 + " ~ " + par2;
					//			break;
					//		case "LOAD":
					//			par1 = pa.GetToken(++i);
					//			//textBox1.AppendText("Load: " + par1);
					//			Image<Bgr, Byte> inputImage = new Image<Bgr, byte>(par1);
					//			imageBox1.Image = inputImage;
					//			break;
					//		case "NEEDGRAB":
					//			par1 = pa.GetToken(++i);
					//			if (par1 == "true")
					//				Global.needGrab = true;
					//			else
					//				Global.needGrab = false;
					//			break;
					//		case "NGVALUE":         //mean
					//			par1 = pa.GetToken(++i);
					//			par2 = pa.GetToken(++i);
					//			Range.meanD = int.Parse(par1);
					//			Range.meanU = int.Parse(par2);
					//			if (Range.meanD > Range.meanU)
					//			{
					//				tmp = Range.meanD;
					//				Range.meanD = Range.meanU;
					//				Range.meanU = tmp;
					//			}
					//			labelNGValue.Text = par1 + " ~ " + par2;
					//			break;
					//		case "RED":
					//			par1 = pa.GetToken(++i);
					//			par2 = pa.GetToken(++i);
					//			Range.redD = int.Parse(par1);
					//			Range.redU = int.Parse(par2);
					//			if (Range.redD > Range.redU)
					//			{
					//				tmp = Range.redD;
					//				Range.redD = Range.redU;
					//				Range.redU = tmp;
					//			}
					//			iniSetup.WriteValue("REDRANGE", "CommandLine", string.Format("{0},{1}", par1, par2));
					//			labelRed.Text = par1 + " ~ " + par2;
					//			break;
					//		case "RESOLUTION":
					//			par1 = pa.GetToken(++i);
					//			par2 = pa.GetToken(++i);
					//			//textBox1.AppendText(bas.IntFeature("Width", int.Parse(par1)));
					//			//textBox1.AppendText(bas.IntFeature("Height", int.Parse(par2)));
					//			//webCap._ksPropertySet.Set()
					//			webCap.setResolution(int.Parse(par1), int.Parse(par2));
					//			break;
					//		case "STARTTESTING":
					//			textBox1.AppendText("\r\nStart testing ..." + labelTestItem.Text);
					//			TestItems.startTestingProcess();
					//			iniSetup.DelSection("CommandLine");
					//			break;
					//		case "STARTTESTLED":
					//			textBox1.AppendText("\r\nStart testing LED ..." + labelTestItem.Text);
					//			TestItems.startTestLED(Global.TestItem);
					//			iniSetup.DelSection("CommandLine");
					//			break;
					//		case "STARTTESTLCD":
					//			textBox1.AppendText("\r\nStart testing LCD ..." + labelTestItem.Text);
					//			TestItems.startTestLCD(Global.TestItem);
					//			iniSetup.DelSection("CommandLine");
					//			break;
					//		case "TESTITEM":
					//			par1 = pa.GetToken(++i);
					//			Global.TestItem = par1;
					//			labelTestItem.Text = par1;
					//			break;
					//		case "THRESHOLD":
					//			par1 = pa.GetToken(++i);
					//			par2 = pa.GetToken(++i);
					//			Range.thresholdD = int.Parse(par1);
					//			Range.thresholdU = int.Parse(par2);
					//			if (Range.thresholdD > Range.thresholdU)
					//			{
					//				tmp = Range.thresholdD;
					//				Range.thresholdD = Range.thresholdU;
					//				Range.thresholdU = tmp;
					//			}
					//			labelRed.Text = par1 + " ~ " + par2;
					//			break;
					//		case "QUIT":
					//			tm.tcpClient.Close();
					//			System.Environment.Exit(2);
					//			break;
					//		case "WEBCAM":
					//			par1 = pa.GetToken(++i);
					//			if (par1 == "true")
					//				Global.useWebCam = true;
					//			else
					//				Global.useWebCam = false;
					//			break;
					//		case "WEBGRAB":
					//			string path = "c:\\ImageLog\\ImageLogAT500\\" + DateTime.Now.ToString("yyyy") + "\\" +
					//				DateTime.Now.ToString("MM") + "\\" + DateTime.Now.ToString("dd") + "\\";
					//			string FileName = path + Global.sn + "-" + Global.TestItem + "-" + DateTime.Now.ToString("yyyyMMddHHmmssff") + ".jpg";
					//			Directory.CreateDirectory(System.IO.Path.GetDirectoryName(path));    //假如路徑不存在則先建立路徑。
					//			Mat frame = new Mat();
					//			webCap.grab1(frame, FileName);
					//			imageBox1.Image = frame;
					//			tm.ServerSend("Vision>>>");
					//			break;
					//		case "ZOOM":        //Exposure, Focus, Zoom三者參數馬上設定，不存到ini中。
					//			par1 = pa.GetToken(++i);
					//			Global.LedNum = int.Parse(par1);
					//			//iniTDVision.WriteValue("Zoom", "", par1);
					//			//iniSetup.WriteValue("Zoom", "CommandLine", string.Format("{0}", par1));
					//			oval = int.Parse(par1);
					//			webCap._camControl.Set(CameraControlProperty.Zoom, oval, bflag);
					//			webCap.setInternal(KSProperties.CameraControlFeature.KSPROPERTY_CAMERACONTROL_ZOOM, oval);
					//			break;
					//		default:
					//			textBox1.AppendText("\r\nNot support ..." + pa.GetToken(i));
					//			break;
					//	}
					//	i++;
					//}
					//parametersUpdate();
				}*/

		private string getIPAddress()
		{
			int num = 1;
			StringBuilder ipAddressList = new StringBuilder();
			//取得本機上ipv4及非Loopback的IP Address
			//ipAddressList.Clear();
			num = 1;
			foreach (System.Net.NetworkInformation.NetworkInterface nic
				in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
			{
				foreach (System.Net.NetworkInformation.IPAddressInformation ipInfo
					in nic.GetIPProperties().UnicastAddresses)
				{
					if (System.Net.IPAddress.IsLoopback(ipInfo.Address) == false
						&& ipInfo.Address.AddressFamily != System.Net.Sockets.AddressFamily.InterNetworkV6)
					{
						//取得IP Address
						ipAddressList.Append("IP #" + num + ": " + ipInfo.Address.ToString() + Environment.NewLine);
						num += 1;
					}
				}
			}
			return (string.Format("\r\n{0}", ipAddressList.ToString()));
		}

		private void connectServerToolStripMenuItem_Click(object sender, EventArgs e)
		{
			tm.ServerConnect(TcpProcess1, "127.0.0.1", 4000);
			tm.ServerSendLine(getIPAddress());
		}

		private void sendServerToolStripMenuItem_Click(object sender, EventArgs e)
		{
			string message = "Haha";
			tm.ServerSend(message);
			labelID.Text = message;
		}

		private void debugMessageToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (tm.sbDebug!= null)
				labelID.Text = tm.sbDebug.ToString();
			//IntPtr APHandle;
			//string RPath, RunPath, fileParameters;
			//RPath = Environment.CurrentDirectory;
			//RunPath = RPath + @"\PUSIGB.exe";
			//fileParameters = " ";
			//APHandle = ShellExecute(IntPtr.Zero, "open", RunPath, fileParameters,
			//	Environment.CurrentDirectory, (int)ShowWindowCommands.SW_HIDE);
			//ServerFileCheck();
			//FileCRC32Check();
			//pictureBox1.Image = new Bitmap(Environment.CurrentDirectory + @"\empty.bmp");
			//CheckBarcode("091020001187A013", true);

			string RunPath = Environment.CurrentDirectory;
			string fileName = gCodeini.ReadString("control", "FCTEXEName", "PUSIGB.exe");
			string fileParameter = gCodeini.ReadString("control", "FCTEXEParameters", " ");
			RunPath = RunPath + @"\PUSIGB.exe";
			//try
			//{
			//	IntPtr APHandle = ShellExecute(IntPtr.Zero, "open", RunPath, fileParameter,
			//		Environment.CurrentDirectory, (int)ShowWindowCommands.SW_HIDE);
			//}
			//catch(Exception ee)
			//{
			//	MessageBox.Show(ee.Message);
			//}
			string command = @"/k dir";
			ProcessStartInfo cmdsi = new ProcessStartInfo("cmd.exe");
			cmdsi.Arguments = command;
			cmdsi.FileName = RunPath;
			cmdsi.Arguments = fileParameter;
			cmdsi.WorkingDirectory = Environment.CurrentDirectory;
			cmdsi.UseShellExecute = false;
			Process cmd = Process.Start(cmdsi);
			cmd.WaitForExit();
			//var items = new List<string>();
			//loadFromFile("testlog1.txt", items);
			labelNet.Text = this.Text;
		}

		private void buttonClose_Click(object sender, EventArgs e)
		{
			tm.SeverClose();
			EmptyBarcode();
			Close();
			//EmptyEMP_NO();
			//if (Comm1.Handle != null)
			//	Comm1.stop();
		}

		private void byteTestToolStripMenuItem_Click(object sender, EventArgs e)
		{
			string str = GetConfigData3("091020001187A013");
			Byte[] aTmp = { 65, 66, 67, 68 };			// A byte array contains non-ASCII (or non-readable) characters
			string s1 = Encoding.UTF8.GetString(aTmp);		// 
			byte[] decBytes1 = Encoding.UTF8.GetBytes(s1);  // decBytes1.Length == 10 !!
															// decBytes1 not same as bytes
															// Using UTF-8 or other Encoding object will get similar results
			labelID.Text = str;
		}

		private void connectCloseToolStripMenuItem_Click(object sender, EventArgs e)
		{
			tm.SeverClose();
		}

		private void buttonSubmit_Click(object sender, EventArgs e)
		{
			string stemp;
			//if (bbprinter.Enabled)
			//	bbprinter.Click();		//將sfc的字串印出。
			stemp = gCodeini.ReadString("control", "ShopFlow", "OFF").ToUpper();
			if (rDTestToolStripMenuItem.Checked)
				MessageBox.Show("SFC is: " + stemp);
			SetIconType((int)IconType.submitbutton);
			if (!stemp.Contains("OFF"))
			{   //送資料到SFC Host
				stemp = ConfigSendData(IconType.submitbutton);
				if (stemp == "")
					return;
				if (!SendDataToHost(stemp))
					return;
			}
			else
			{
				ClearInputData();
				EmptyBarcode();
			}
			//textBoxBarcode.Focus();
		}

		private void buttonRetest_Click(object sender, EventArgs e)
		{
			//if (Comm1.handle != 0)
			//	Comm1.stopComm();
			restoreToolStripMenuItem_Click(sender, e);
			buttonOK_Click(sender, e);
		}

		private void restoreToolStripMenuItem_Click(object sender, EventArgs e)
		{
			ClearInputData();
			SetIconType((IconType)0);
			int imac;
			gbRestore = true;
			imac = gCodeini.ReadInteger("control", "MultiMAC", 1);
			if (imac > 1)
			{
				SetIconType((IconType)(-1));
				return;
			}
			SetIconType((IconType)0);
			try
			{
				if (gbChangeini)
				{
					if (textBoxConfig.Enabled)
						textBoxConfig.Text = gChangeini.ReadString("code", "config", "0");
					textBoxBarcode.Text = gChangeini.ReadString("restore", "barcode", "0");
					if ((textBoxMac.Enabled))
						textBoxMac.Text = gChangeini.ReadString("restore", "MAC", "0");
					if (textBoxGuid.Enabled)
						textBoxGuid.Text = gChangeini.ReadString("restore", "GUID", "0");
				}
				else
				{
					if (textBoxConfig.Enabled)
						textBoxConfig.Text = gCodeini.ReadString("code", "config", "0");
					textBoxBarcode.Text = gCodeini.ReadString("restore", "barcode", "0");
					if (textBoxMac.Enabled)
						textBoxMac.Text = gCodeini.ReadString("restore", "MAC", "0");
					if (textBoxGuid.Enabled)
						textBoxGuid.Text = gCodeini.ReadString("restore", "GUID", "0");
				}
			}
			catch { gbRestore = false; }
			gbRestore = false;
			Mouse.DoMouseMoveTo(this.Location.X + buttonOK.Location.X + 50, this.Location.Y + buttonOK.Location.Y + 50);
			//Cursor.Position = new Point(this.Location.X + buttonOK.Location.X + 50, this.Location.Y + buttonOK.Location.Y + 50);
			//DoMouseClick(this.Location.X + buttonOK.Location.X + 50, this.Location.Y + buttonOK.Location.Y + 50);
		}

		private void Form1_FormClosing(object sender, FormClosingEventArgs e)
		{
			tm.SeverClose();
			ClientSocket1.Active = false;
		}

		private void textBoxBarcode_TextChanged(object sender, EventArgs e)
		{
			int itemp, ilength;
			itemp = gCodeini.ReadInteger("control", "BarcodeLength", 0);
			ilength = textBoxBarcode.Text.Length;
			if ((ilength > 2) && (gdstar == DateTime.MinValue))
				gdstar = DateTime.Now;
			//if (Comm1.Handle > 0) { }		//自動掃描barcode
			if (gbRestore)
			{
				itemp = gCodeini.ReadInteger("control", "BarcodeLength", 0);
				ilength = textBoxBarcode.Text.Length;
				if (itemp != ilength)
				{
					textBoxBarcode.Text = "";
					return;
				}
				gdEnd = DateTime.Now;
				TimeSpan sp = gdEnd - gdstar;
				if (sp.Seconds > 3)
				{
					textBoxBarcode.Text = "";
					gdstar = DateTime.MinValue;
					return;
				}
				gdstar = DateTime.MinValue;
				//判斷Barcode是否指到正確目錄
				if (!CheckBarcode(textBoxBarcode.Text, true))
				{
					if (!gbBatchNumber)
					{
						MessageBox.Show("Barcode data error.\n\r", "gbBatchNumber");
						OpenVersionForm();
						buttonClose_Click(sender, e);
						Close();
					}
					else
					{
						textBoxBarcode.Focus();
						return;
					}
				}
				if (textBoxConfig.Visible)
				{
					textBoxConfig.Text = GetConfigData3(textBoxBarcode.Text);
					if (textBoxConfig.Text.Length == 0)
					{
						MessageBox.Show("Config data Error.");
						textBoxBarcode.Text = "";
						textBoxBarcode.Focus();
						return;
					}
					if (gbChangeini)
						gChangeini.WriteString("code", "CONFIG", textBoxConfig.Text);
					else
						gCodeini.WriteString("code", "CONFIG", textBoxConfig.Text);
					if (SetConfgMAC(textBoxConfig.Text))
						textBoxMac.Enabled = true;
					else
					{
						textBoxMac.Enabled = false;
						if (gbChangeini)
							gChangeini.WriteString("code", "MAC", "");
						else
							gCodeini.WriteString("code", "MAC", "");
					}
					//加上USI的OS, Version的變更資料
					//if (cbusi.Checked) { }
				}   //end of if (textBoxConfig.Visible)
				textBoxBarcode.Enabled = false;
				if (gbChangeini)
					gChangeini.WriteString("code", "Barcode", textBoxBarcode.Text);
				else
					gCodeini.WriteString("code", "Barcode", textBoxBarcode.Text);
				if (textBoxMac.Enabled)
				{
					textBoxMac.Focus();
					//如果有多個MAC需要輸入，則在此作初始動作
					textBoxMac.Tag = 1;
					if (gbChangeini)
						gChangeini.EraseSection("MultiMAC");
					else
						gCodeini.EraseSection("MultiMAC");
				}
				else
				{
					if (textBoxGuid.Enabled)
						textBoxGuid.Focus();
					else if (!buttonOK.Enabled)
						SetIconType(IconType.okbutton);			
				}
				textBoxBarcode.Enabled = true;
			}   //end of if (gbRestore)
		}

		private string GetConfigData3(string Barcode)
		{
			string stemp, mycode, SFIS;
			TIniFile AConfigini;
			int iStart, iLength;
			string result = "";
			//決定systembom.ini的路徑。Ubarcode.pas中較複雜，這裡先簡單指定。
			stemp = gFilePath + @"\..\systembom.ini";
			if (!File.Exists(stemp))
			{
				MessageBox.Show("File not Exist: " + stemp);
				return (result);
			}
			AConfigini = new TIniFile(stemp);
			//在這加入判斷是否由SFISBOM來取得BOM的資料。
			SFIS = AConfigini.ReadString("control", "SFISBOM", "OFF");
			if (SFIS == "ON")
			{
				throw new NotImplementedException();
			}   //end of SFIS=="ON"
			else
			{   //SFIS=="OFF"
				iStart = gCodeini.ReadInteger("Position", "START", 1);
				iLength = gCodeini.ReadInteger("Position", "LENGTH", 1);
				if (Barcode.Length >= (iStart - 1 + iLength))
				{
					mycode = Barcode.Substring(iStart - 1, iLength);
					stemp = AConfigini.ReadString("CONFIG", mycode, "").Trim();
				}
				else
					stemp = "";
			}
			//加入USI的資料所要的判斷。
			//mycode = gCodeini.ReadString("Position", "USIADD", "OFF").Trim();
			//判斷是否要把MAC的視窗打開。
			return (stemp);
		}

		private void timerClose_Tick(object sender, EventArgs e)
		{
			giCloseTag = giCloseTag + 1;
			labelNet.Text = giCloseTag.ToString();
			if (giCloseTag > 18)
			{
				timerClose.Enabled = false;
				Close();
			}
		}

		private void timerFind_Tick(object sender, EventArgs e)
		{
			string spass;
			if (FindBarcodeWindow(gcaption))
			{	//PUSIGB 正在執行，將PBarcodeForm縮小。
				this.WindowState = FormWindowState.Minimized;
				if (gbChangeini)
				{
					if (gChangeini.ValueExists("ActiveSync", "CAPTION"))
					{
						spass = gChangeini.ReadString("ActiveSync", "CAPTION", "NODATA").Trim();
						FindWindowClose(spass);
						if (gChangeini.ValueExists("ActiveSync", "CAPTION2"))
						{
							spass = gChangeini.ReadString("ActiveSync", "CAPTION2", "NODATA").Trim();
							FindWindowClose(spass);
						}
					}
				}
			}
			else
			{	//PUSIGB 已經結束，將PBarcodeForm回復。
				this.WindowState = FormWindowState.Normal;
				this.Focus();
				textBoxBarcode.Text = "";
				textBoxBarcode.Focus();
				timerFind.Enabled = false;	//結束timerFind。
				//檢查掃條碼
			}
			//buttonSubmit_Click(sender, e);
		}

		private bool FindWindowClose(string sCaption)
		{
			IntPtr hWinMain;
			const Int32 WM_SysCommand = 0x112;
			const Int32 SC_MiniMize = 0xf020;
			hWinMain = User32.FindWindow(null, sCaption);
			if (hWinMain != IntPtr.Zero)
				User32.SendMessage(hWinMain, WM_SysCommand, SC_MiniMize, 0);
			return true;
		}

		private bool FindBarcodeWindow(string aCaption)
		{
			IntPtr hWinMain;
			hWinMain = User32.FindWindow(null, aCaption);
			if (hWinMain != IntPtr.Zero)
				return true;
			else
				return false;
		}

		private void timerToHost_Tick(object sender, EventArgs e)
		{   //timerToHost()
			if (!gbTimerToHost)
				timerToHost.Tag = 130;
			if ((int)timerToHost.Tag < 120)
			{
				Application.DoEvents();
				timerToHost.Tag = (int)timerToHost.Tag + 1;
			}
			else
			{
				timerToHost.Tag = 0;
				timerToHost.Enabled = false;
				ClientSocket1.Active = false;
				//計時器超過時間，而且是在程式執行等待回應時。
				if (gbTimerToHost)
				{
					labelNet.Text = "The host no response, retest Please 2";
					pictureBox1.Image = new Bitmap(Environment.CurrentDirectory + @"\error.bmp");
					if (gWhoSendToHost == (int)IconType.okbutton)
						SetIconType(IconType.okbutton);
					else
						SetIconType(IconType.submitbutton);
				}
				Cursor = Cursors.Default;
			}
		}

		private void buttonLogout_Click(object sender, EventArgs e)
		{
			ClearInputData();
			buttonClose_Click(sender, e);
		}

		private void rDTestToolStripMenuItem_Click(object sender, EventArgs e)
		{
			rDTestToolStripMenuItem.Checked = !rDTestToolStripMenuItem.Checked;
		}

		private void barcodeOKToolStripMenuItem_Click(object sender, EventArgs e)
		{
			//timerRobertArm.Enabled = false;
			labelNet.Text = "";
			textBoxBarcode.Text = comboBox1.Text;	// "091020001187A013";
			System.Threading.Thread.Sleep(1000);
			SetIconType(IconType.okbutton);
			barcodeOKCommand(textBoxBarcode.Text);
			//textBoxBarcode_TextChanged(null, null);
			//System.Threading.Thread.Sleep(3000);
			//System.Threading.Thread.Sleep(1000);
			//buttonOK_Click(sender, null);
			//textBoxBarcode.Text = "";
			//timerRobertArm.Enabled = true;
		}

		private void barcodeOKCommand(object code)
		{
			if (!gLooping)
			{
				gLooping = true;
				SetIconType((int)IconType.okbutton);
				string barcode = (string)code;
				KeyEventArgs ek = new KeyEventArgs(Keys.Enter);
				//textBoxBarcode_KeyUp(null, ek);
				if (ek.KeyValue == 13)
				{
					int itemp, ilength;
					itemp = gCodeini.ReadInteger("control", "BarcodeLength", 0);
					ilength = textBoxBarcode.Text.Length;
					if (itemp != ilength)
					{   //檢查輸入的條碼長度(ilength)符合預期(itemp)
						textBoxBarcode.Text = "";
						return;
					}
					gdEnd = DateTime.Now;
					TimeSpan ts = gdEnd - gdstar;
					if (!gbTDMode)
					{
						if (ts.Seconds > 1)
						{
							textBoxBarcode.Text = "";
							gdstar = DateTime.Now;
							return;
						}
					}
					gdstar = DateTime.Now;
					//檢查Barcode是否指到正確目錄。怎樣是指到正確目錄？
					if (!CheckBarcode(textBoxBarcode.Text, true))
					{
						if (!gbBatchNumber)
						{
							SetLabelNetText("Barcode data Error.");
							//MessageBox.Show("Barcode data Error.");
							OpenVersionForm();
							buttonClose_Click(null, null);
							Close();
						}
						else
						{
							textBoxBarcode.Focus();
							return;
						}
					}
					//if (textBoxConfig.Visible), 參考textBoxBarcode_KeyUp()中的部份。
					//textBoxBarcode.Enabled = false;
					//設定三分鐘計時關閉
					//giCloseTag = 0;
					//timerClose.Enabled = true;
					if (gbChangeini)
						gChangeini.WriteString("code", "Barcode", textBoxBarcode.Text);
					else
						gCodeini.WriteString("code", "Barcode", textBoxBarcode.Text);
					//檢查長度
					//if (textBoxMac.Enabled), 檢查，處理MAC, GUID。
					//textBoxBarcode.Enabled = true;
				}   //if (e.KeyValue == 13)
				gdstar = DateTime.Now;
				textBoxBarcode_TextChanged(null, null);
				Thread.Sleep(1000);
				buttonOK_Click(null, null);
				gLooping = false;
			}
		}
		int robertStatus = 0;
		private void timerRobertArm_Tick(object sender, EventArgs e)
		{
			if (this.tcpPassiveEngine == null)
				return;
			if (this.tcpPassiveEngine.Connected != true)
				return;
			timerRobertArm.Enabled = true;
			if (robertStatus == 0)      //robertStatus:0:開機。1:連上server。2,3:send ready。4,5:testing。6,7:send result。
			{
				this.Invoke(new MethodInvoker(() => { connectServerToolStripMenuItem1.PerformClick(); })); //連接robert server。
			}
			if (robertStatus == 1)
				this.Invoke(new MethodInvoker(() => { sendReadyToolStripMenuItem.PerformClick(); })); //通知server已準備好。
			if (robertStatus == 6)
				this.Invoke(new MethodInvoker(() => { sendResultToolStripMenuItem.PerformClick(); })); //通知server測試完成。
			if (robertStatus == 19)
				robertStatus = 6; //通知server測試完成。
			if (robertStatus == 21)
				robertStatus = 1; //通知server測試完成。
			string st = labelServerStatus.Text.Substring(2);
			labelServerStatus.Text = robertStatus.ToString("D2") + st;

			
			if (!FindBarcodeWindow(gcaption))
			{
				if (gLooping)
					return;
				this.WindowState = FormWindowState.Normal;
				//barcodeOKToolStripMenuItem_Click(sender, e);
				barcodeLoopToolStripMenuItem_Click(sender, e);
			}
			else
				this.WindowState = FormWindowState.Minimized;

		}

		private void barcodeAutoToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Thread thA = new Thread(new ParameterizedThreadStart(barcodeOKCommand));
			thA.Name = "BarcodeOK";
			//timerRobertArm.Enabled = false;
			textBoxBarcode.Text = comboBox1.Text;		// "091020001187A013";
			System.Threading.Thread.Sleep(1000);
			thA.Start(textBoxBarcode.Text);
		}

		private void barcodeOToolStripMenuItem_Click(object sender, EventArgs e)
		{
			textBoxBarcode.Text = comboBox1.Text;		// "091020001187A013";
			System.Threading.Thread.Sleep(1000);
			SetIconType(IconType.okbutton);
			KeyEventArgs ek = new KeyEventArgs(Keys.Enter);
			textBoxBarcode_KeyUp(null, ek);
		}

		private void barcodeLoopToolStripMenuItem_Click(object sender, EventArgs e)
		{
			barcodeAutoToolStripMenuItem.Checked = true;
			if (loopingToolStripMenuItem.Checked)
				return;
			Thread thA = new Thread(new ParameterizedThreadStart(barcodeOKCommand));
			thA.Name = "BarcodeOK";
			//timerRobertArm.Enabled = false;
			textBoxBarcode.Text = comboBox1.Text;		// "091020001187A013";
			System.Threading.Thread.Sleep(1000);
			thA.Start(textBoxBarcode.Text);
		}

		private void timerRobertToolStripMenuItem_Click(object sender, EventArgs e)
		{
			timerRobertArm.Enabled = !timerRobertArm.Enabled;
			timerRobertToolStripMenuItem.Checked = timerRobertArm.Enabled; ;
		}

		private void armConnectToolStripMenuItem_Click(object sender, EventArgs e)
		{
			int port = gChangeini.ReadInteger("RobertArm", "port", 0);
			string hostIp = gChangeini.ReadString("RobertArm", "IPAddress", "127.0.0.1");
			TcpClient tc = new TcpClient(hostIp, port);
			NetworkStream ns = tc.GetStream();
			StreamReader sr = new StreamReader(ns);
			StreamWriter sw = new StreamWriter(ns);
			string receiveMsg = string.Empty;
			string recMsg = string.Empty;
			byte[] receiveByte = new byte[256];
			ClearInputData();
			labelNet.Text = "Request Arm.";
			SetIconType((IconType)0);
			//textBoxMac.Enabled = true;
			for(int i = 0; i < 10; i++)
			{
				if (ns.CanWrite)
				{
					//byte[] msgByte = Encoding.Default.GetBytes("Load"+i);
					//ns.Write(msgByte, 0, msgByte.Length);
					sw.Write("Load" + i);
					sw.Flush();
				}
				while (ns.CanRead && !ns.DataAvailable)
					Thread.Sleep(20);
				if (ns.CanRead)
				{
					if (ns.DataAvailable)
					{
						while (ns.DataAvailable)
						{
							//int numberOfByteRead = 0;
							//numberOfByteRead = ns.Read(receiveByte, 0, 256);
							//receiveMsg = Encoding.Default.GetString(receiveByte, 0, numberOfByteRead);
							recMsg = sr.ReadLine();
						};
						//textBoxMac.Text = receiveMsg;
						labelNet.Text = recMsg;
						if (ns.CanWrite)
						{
							sw.Write("LoadBarcode" + i);
							sw.Flush();
						}
						while (ns.CanRead && !ns.DataAvailable)
							Thread.Sleep(20);
						if (ns.CanRead)
						{
							if (ns.DataAvailable)
							{
								while (ns.DataAvailable)
								{
									recMsg = sr.ReadLine();
								};
								textBoxBarcode.Text = recMsg;
							}
						}
						break;
					}
				}
				Thread.Sleep(50);
			}
			Thread.Sleep(500);
			SetIconType((IconType)1);
			Cursor.Position = new Point(Cursor.Position.X + 370, Cursor.Position.Y + 96);

		}

		private void serialPortToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Mouse.DoMouseClick(this.Location.X + buttonClose.Location.X + 50, this.Location.Y + buttonClose.Location.Y + 50);
			//SerialPort comPort;
			//comPort = new SerialPort("COM4", 115200, Parity.None, 8, StopBits.One);
			//comPort.BaseStream
		}

		private void buttonOK_Click(object sender, EventArgs e)
		{
			string stemp;
			int icount=0;
			giCloseTag = 0;		//結束3分鐘計時。在PBarcodeForm 3分鐘没輸入條碼則會結束程式。
			timerClose.Enabled = false;
			if (gbSymbolini)
				if (DeviceAdd())
					if (!DeviceCheck())
					{
						Close();
						return;
					}
			//if (Comm1.Handle != null)
			//	Comm1.stop();
			stemp = gCodeini.ReadString("control", "ShopFlow", "OFF").ToUpper();
			BackupBarcode();	//將輸入的資料存到全域變數。
			if (stemp.Contains("OFF"))
			{	//ShopFlow = OFF
				if ((! OpenMainForm()) &&(icount > 5))
				{
					MessageBox.Show("Open PUSIGB.EXE error.");
					return;
				}
				SetIconType((int)IconType.okbutton);
				if (!buttonSubmit.Enabled)
					SetIconType((int)IconType.submitbutton);
				System.Threading.Thread.Sleep(1000);
				timerFind.Enabled = true;
				//if (Comm1.Handle != null)
				//	Comm1.stop();
				robertStatus = 6;
			}
			else
			{	//ShopFlow = ON
				if (!rDTestToolStripMenuItem.Checked)
				{
					if (!ServerFileCheck())
					{	//比對fctcommand.txt, dio.ini
						MessageBox.Show("Not match download server data!");
						Close();
					}
					if (!FileCRC32Check())
					{	//比對check sum
						MessageBox.Show("File checsum error!");
						Close();
					}
				}   //rdtest1.checked
				if ((!OpenMainForm()) && (icount > 5))
				{
					MessageBox.Show("Open PUSIGB.EXE error.");
					return;
				}
				SetIconType((int)IconType.okbutton);
				//stemp = ConfigSendData(IconType.okbutton);
				stemp = ConfigSendData(IconType.submitbutton);
				timerFind.Enabled = true;
				if (stemp == "")
				{
					labelNet.Text = "Get Send Data Error.";
					return;
				}
				robertStatus = 6;
				if (!SendDataToHost(stemp))
					return;
			}
			//if (!ServerSUSIGB.Active)
			//	ServerSUSIGB.Active = true;
			//this.Invoke(new MethodInvoker(() => { sendResultToolStripMenuItem.PerformClick(); })); //將條碼及結果傳給Server。
			robertStatus = 6;
		}

		private bool SendDataToHost(string data)
		{
			//MemoryStream ms;
			//bool result;
			if (rDTestToolStripMenuItem.Checked)
				MessageBox.Show("RD Test1: " + data);
			if (!ClientSocket1.Active)
				ClientSocket1.Active = true;
			if (!timerToHost.Enabled)
				timerToHost.Enabled = true;
			try
			{
				while (!ClientSocket1.tcpClient.Connected)
				{
					int port = gChangeini.ReadInteger("host", "port", 1024);
					string host = gChangeini.ReadString("host", "IPAddress", "127.0.0.1");
					Application.DoEvents();
					ClientSocket1.ServerConnect(Client1, host, port);
					if (!timerToHost.Enabled)
						return false;
				}
				SetLabelNetText("wait.bmp");
				ClientSocket1.ServerSend(data);
			}
			catch
			{
				timerToHost.Tag = 119;
				SetLabelNetText("connect host fail 1");
				return false;
			}
			return true;
		}

		private void connectServerToolStripMenuItem1_Click(object sender, EventArgs e)
		{
			string robertIP = comboBoxIP.Text;
			string robertPort = comboBoxPort.Text;
			if (this.comboBoxIP.Text == "")
				robertIP = gCodeini.ReadString("Robert","IP","10.5.33.114");
			if (comboBoxPort.Text == "")
				robertPort = gCodeini.ReadString("Robert", "Port", "9000");
			if ((robertPort=="")||(robertIP==""))
			{
				ShowResult("Robert IP Error.");
				return;
			}
			try
			{
				//初始化并启动客户端引擎（TCP、文本协议）
				this.tcpPassiveEngine = NetworkEngineFactory.CreateStreamTcpPassivEngine(robertIP, int.Parse(robertPort), new StreamContractHelper());
				this.tcpPassiveEngine.MessageReceived += new CbDelegate<System.Net.IPEndPoint, byte[]>(tcpPassiveEngine_MessageReceived);
				this.tcpPassiveEngine.ConnectionInterrupted += new CbDelegate(tcpPassiveEngine_ConnectionInterrupted);
				this.tcpPassiveEngine.ConnectionRebuildSucceed += new CbDelegate(tcpPassiveEngine_ConnectionRebuildSucceed);
				this.tcpPassiveEngine.AutoReconnect = true;		//启动掉线自动重连                
				this.tcpPassiveEngine.Initialize();
				ShowResult("连接成功！");
				robertStatus = 1;
			}
			catch (Exception ee)
			{
				MessageBox.Show(ee.Message);
			}
			//System.Threading.Thread.Sleep(3000);
			//this.Invoke(new MethodInvoker(() => { sendReadyToolStripMenuItem.PerformClick(); })); //通知server已準備好。
		}

		private void sendReadyToolStripMenuItem_Click(object sender, EventArgs e)
		{
			ShowResult("发送Ready请求");
			//发送ready
			int msgType = MessageType.ClientSendReady;
			MsgRequestContract contract = new MsgRequestContract("", "");
			contract.Key = Guid.NewGuid().ToString();
			byte[] bBody = SerializeHelper.SerializeObject(contract);

			//消息头
			MessageHead head = new MessageHead(bBody.Length, msgType);
			byte[] bHead = head.ToStream();

			//构建请求消息
			byte[] reqMessage = new byte[bHead.Length + bBody.Length];
			Buffer.BlockCopy(bHead, 0, reqMessage, 0, bHead.Length);
			Buffer.BlockCopy(bBody, 0, reqMessage, bHead.Length, bBody.Length);

			//发送请求消息
			this.tcpPassiveEngine.PostMessageToServer(reqMessage);
			robertStatus = 3;
		}

		void tcpPassiveEngine_MessageReceived(System.Net.IPEndPoint serverIPE, byte[] bMsg)
		{
			//获取消息类型
			int msgType = BitConverter.ToInt32(bMsg, 4);//消息类型是 从offset=4处开始 的一个整数

			if (msgType == MessageType.ServerResponseBarCode)		//MsgType:6，服務端收到客戶端Ready請求。
			{
				#region 服务端收到客戶端請求
				MsgResponseContract response = (MsgResponseContract)SerializeHelper.DeserializeBytes(bMsg, MessageHead.HeadLength, bMsg.Length - MessageHead.HeadLength);
				string result =robertStatus+ ":服务端回應:6," + response.Msg;
				this.ShowResult(result);
				gBarcode = response.Msg;
				robertStatus = 2;
				#endregion
				robertStatus = 17;
			}
			if (msgType == NewMessageType.ServerPlaceDevice)		//msgType:8，服務端放好機台，給定條碼。
			{
				#region 服務端放好機台，給定條碼
				MsgResponseContract response = (MsgResponseContract)SerializeHelper.DeserializeBytes(bMsg, MessageHead.HeadLength, bMsg.Length - MessageHead.HeadLength);
				string result = robertStatus+":服务端放好機台:8," + response.Msg;
				this.ShowResult(result);
				gBarcode = response.Msg;
				//gBarcode = "H0699361010-1234567890";
				this.Invoke(new MethodInvoker(() => { testUpdateToolStripMenuItem.PerformClick(); })); //將條碼填入textBoxBarcode，等待ok按下. 開始測試。
				#endregion
				robertStatus = 19;
			}
			if (msgType == NewMessageType.SeverReceiveResult)		//msgType:10，服務端收到測試完成。
			{
				#region 服務端收到測試完成
				MsgResponseContract response = (MsgResponseContract)SerializeHelper.DeserializeBytes(bMsg, MessageHead.HeadLength, bMsg.Length - MessageHead.HeadLength);
				string result = robertStatus+":服务端收到測試完成:10," + response.Msg;
				this.ShowResult(result);
				robertStatus = 7;
				#endregion
				robertStatus = 21;
			}
			if (msgType == NewMessageType.ServerTakeDevice)       //msgType:11，服務端拿走待測物。
			{
				#region 服務端拿走待測物
				MsgResponseContract response = (MsgResponseContract)SerializeHelper.DeserializeBytes(bMsg, MessageHead.HeadLength, bMsg.Length - MessageHead.HeadLength);
				string result = robertStatus+":服务端拿走待測物:11," + response.Msg;
				this.ShowResult(result);
				//客户端发送给服务端條碼及測試結果
				result += ".发送條碼及測試結果给服务端";
				this.ShowResult(result);
				msgType = NewMessageType.ClientSendResult;		//.ClientSendReceive;
				MsgRequestContract contract = new MsgRequestContract("", "");
				string scode = "";
				if (gbChangeini)
					scode = gChangeini.ReadString("code", "Barcode", "*");
				else
					scode = gCodeini.ReadString("code", "Barcode", "*");
				scode = scode.ToUpper();
				string spass = GetTestMessage();
				if (spass != "PASS")
					spass = "FAIL";
				//發送條碼及測試結果，
				contract.Msg = scode + "," + spass;     //barcode:scode, result: PASS/FAIL .
				contract.Key = Guid.NewGuid().ToString();
				byte[] bBody = SerializeHelper.SerializeObject(contract);
				//消息头
				MessageHead head = new MessageHead(bBody.Length, msgType);
				byte[] bHead = head.ToStream();
				//构建请求消息
				byte[] reqMessage = new byte[bHead.Length + bBody.Length];
				Buffer.BlockCopy(bHead, 0, reqMessage, 0, bHead.Length);
				Buffer.BlockCopy(bBody, 0, reqMessage, bHead.Length, bBody.Length);
				//发送请求消息
				this.tcpPassiveEngine.PostMessageToServer(reqMessage);
				robertStatus = 1;
				//System.Threading.Thread.Sleep(10000);	//等待時間。
				//this.Invoke(new MethodInvoker(() => { sendReadyToolStripMenuItem.PerformClick(); })); //傳送ready給伺服器。
				#endregion
				robertStatus = 22;
			}
			if (msgType == NewMessageType.ServerTakeDeviceAndPlaceDevice)       //msgType:12，服務端拿走待測物並放上新機。
			{
				#region 服務端拿走待測物並放上新機。
				//string result = "客户端收到服务端返回结果";
				//this.ShowResult(result);
				MsgResponseContract response = (MsgResponseContract)SerializeHelper.DeserializeBytes(bMsg, MessageHead.HeadLength, bMsg.Length - MessageHead.HeadLength);
				string result = robertStatus+":服务端拿走待測物並放新機:12," + response.Msg;
				this.ShowResult(result);
				//客户端发送给服务端條碼及測試結果
				result += ".发送條碼及測試結果给服务端";
				this.ShowResult(result);
				msgType = NewMessageType.ClientSendResult;
				MsgRequestContract contract = new MsgRequestContract("", "");
				string scode = "";
				if (gbChangeini)
					scode = gChangeini.ReadString("code", "Barcode", "*");
				else
					scode = gCodeini.ReadString("code", "Barcode", "*");
				scode = scode.ToUpper();
				string spass = GetTestMessage();
				if (spass != "PASS")
					spass = "FAIL";
				contract.Msg = scode + "," + spass;     //"barcode,OK";    //gBarcode + ",OK";	//barcode:gBarcode, result: OK/FAIL .
				contract.Key = Guid.NewGuid().ToString();
				byte[] bBody = SerializeHelper.SerializeObject(contract);

				//消息头
				MessageHead head = new MessageHead(bBody.Length, msgType);
				byte[] bHead = head.ToStream();
				//构建请求消息
				byte[] reqMessage = new byte[bHead.Length + bBody.Length];
				Buffer.BlockCopy(bHead, 0, reqMessage, 0, bHead.Length);
				Buffer.BlockCopy(bBody, 0, reqMessage, bHead.Length, bBody.Length);
				//发送请求消息
				this.tcpPassiveEngine.PostMessageToServer(reqMessage);

				//gBarcode = "H0699361010-1234567890";
				//this.Invoke(new MethodInvoker(() => { testUpdateToolStripMenuItem.PerformClick(); })); //☆
				gBarcode = response.Msg;
				this.Invoke(new MethodInvoker(() => { testUpdateToolStripMenuItem.PerformClick(); })); //將條碼填入textBoxBarcode，等待ok按下. 開始測試。
				#endregion
				robertStatus = 23;
			}
			if (msgType == NewMessageType.ServerReceiveTestFinished)       //msgType:14，服務端收到客戶端測試結束。
			{
				#region 服务端收到測試完成
				MsgResponseContract response = (MsgResponseContract)SerializeHelper.DeserializeBytes(bMsg, MessageHead.HeadLength, bMsg.Length - MessageHead.HeadLength);
				string result = robertStatus+":服务端收到測試完成:14," + response.Msg;
				this.ShowResult(result);
				#endregion
				robertStatus = 25;
			}
		}

		void tcpPassiveEngine_ConnectionInterrupted()
		{
			if (this.InvokeRequired)
			{
				this.BeginInvoke(new CbDelegate(this.tcpPassiveEngine_ConnectionInterrupted));
			}
			else
			{
				// this.button1.Enabled = false;
				//MessageBox.Show("您已经掉线。");
				this.ShowResult("您已经掉线。");
			}
		}

		void tcpPassiveEngine_ConnectionRebuildSucceed()
		{
			if (this.InvokeRequired)
			{
				this.BeginInvoke(new CbDelegate(this.tcpPassiveEngine_ConnectionInterrupted));
			}
			else
			{
				// this.button1.Enabled = true;
				//MessageBox.Show("重连成功。");
				this.ShowResult("重连成功。");
			}
		}

		private void ShowResult(string result)
		{
			//MessageBox.Show(result);
			if (this.InvokeRequired)
			{
				this.BeginInvoke(new CbDelegate<string>(this.ShowResult), result);
			}
			else
			{
				// this.label_result.Text = result;
				//rtbInfo.AppendText(result + "\r\n");
				labelServerStatus.Text = result;
			}
		}

		private void sendResultToolStripMenuItem_Click(object sender, EventArgs e)
		{
			string spass = GetTestMessage();
			#region 客户端发送结果
			ShowResult("发送结果");
			//发送ready
			int msgType = NewMessageType.ClientSendTestFinished;
			MsgRequestContract contract = new MsgRequestContract("", "");
			//	contract.Msg = "barcode,OK";	//gBarcode + ",OK";	//barcode:gBarcode, result: OK/FAIL .
			string scode = "";
			if (gbChangeini)
				scode = gChangeini.ReadString("code", "Barcode", "*");
			else
				scode = gCodeini.ReadString("code", "Barcode", "*");
			scode = scode.ToUpper();
			//string spass = GetTestMessage();
			if (spass != "PASS")
				spass = "FAIL";
			//發送條碼及測試結果，
			contract.Msg = scode + "," + spass;     //barcode:scode, result: PASS/FAIL .
			contract.Key = Guid.NewGuid().ToString();
			byte[] bBody = SerializeHelper.SerializeObject(contract);

			//消息头
			MessageHead head = new MessageHead(bBody.Length, msgType);
			byte[] bHead = head.ToStream();

			//构建请求消息
			byte[] reqMessage = new byte[bHead.Length + bBody.Length];
			Buffer.BlockCopy(bHead, 0, reqMessage, 0, bHead.Length);
			Buffer.BlockCopy(bBody, 0, reqMessage, bHead.Length, bBody.Length);

			//发送请求消息
			this.tcpPassiveEngine.PostMessageToServer(reqMessage);
			#endregion
		}

		private void closeConnectToolStripMenuItem_Click(object sender, EventArgs e)
		{
			//初始化并启动客户端引擎（TCP、文本协议）
			this.tcpPassiveEngine.CloseConnection();
			//this.textBox_IP.ReadOnly = false;
			//this.textBox_port.ReadOnly = false;
			//MessageBox.Show("連線關閉。");
			this.ShowResult("連線關閉。");
		}

		private void timerPosition_Tick(object sender, EventArgs e)
		{
			labelFixtureID.Text = String.Format("{0},{1}", Cursor.Position.X, Cursor.Position.Y);
		}

		private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
		{

		}

		private void loopingToolStripMenuItem_Click(object sender, EventArgs e)
		{
			for (int i =0; i<20; i++)
			{
				labelNet.Text = "";
				labelID.Text = "ID: "+i.ToString();
				textBoxBarcode.Text = comboBox1.Text;   // "091020001187A013";
				System.Threading.Thread.Sleep(3000);
				SetIconType(IconType.okbutton);
				System.Threading.Thread.Sleep(3000);
				//barcodeOKCommand(textBoxBarcode.Text);
				buttonOK_Click(sender, e);
			}

			//Thread thA = new Thread(new ParameterizedThreadStart(barcodeOKCommand));
			//thA.Name = "BarcodeOK";
			////timerRobertArm.Enabled = false;
			//textBoxBarcode.Text = comboBox1.Text;       // "091020001187A013";
			//System.Threading.Thread.Sleep(1000);
			//thA.Start(textBoxBarcode.Text);

			//labelNet.Text = "";
			//textBoxBarcode.Text = comboBox1.Text;   // "091020001187A013";
			//System.Threading.Thread.Sleep(1000);
			//SetIconType(IconType.okbutton);
			//barcodeOKCommand(textBoxBarcode.Text);

		}

		private void looping50ToolStripMenuItem_Click(object sender, EventArgs e)
		{
			//gbRestore = true;
			for (int i = 0; i < 51; i++)
			{
				labelNet.Text = "";
				labelID.Text = "ID: " + i.ToString();
				textBoxBarcode.Text = comboBox1.Text;
				System.Threading.Thread.Sleep(3000);
				SetIconType(IconType.okbutton);
				System.Threading.Thread.Sleep(3000);
				//barcodeOKCommand(textBoxBarcode.Text);
				buttonOK_Click(sender, e);
			}

		}

		private void looping100ToolStripMenuItem_Click(object sender, EventArgs e)
		{
			for (int i = 0; i < 101; i++)
			{
				labelNet.Text = "";
				labelID.Text = "ID: " + i.ToString();
				textBoxBarcode.Text = comboBox1.Text;   // "091020001187A013";
				System.Threading.Thread.Sleep(3000);
				SetIconType(IconType.okbutton);
				System.Threading.Thread.Sleep(3000);
				//barcodeOKCommand(textBoxBarcode.Text);
				buttonOK_Click(sender, e);
			}

		}

		private void updateBarcodeToolStripMenuItem_Click(object sender, EventArgs e)
		{
			textBoxBarcode.Text = gBarcode;
			//textBoxBarcode.Text = "H0699232610-1234567890";
			buttonOK.PerformClick();
			//string testResult = GetTestMessage();	//get PUSIGB test result

		}

		private void testUpdateToolStripMenuItem_Click(object sender, EventArgs e)
		{
			updateBarcodeToolStripMenuItem.PerformClick();
		}

		private void contineServerToolStripMenuItem_Click(object sender, EventArgs e)
		{
			this.Invoke(new MethodInvoker(() => { connectServerToolStripMenuItem1.PerformClick(); })); //連接server。
			System.Threading.Thread.Sleep(3000);
			this.Invoke(new MethodInvoker(() => { sendReadyToolStripMenuItem.PerformClick(); })); //通知server已準備好。
			
		}

		private void connectSFISServerToolStripMenuItem_Click(object sender, EventArgs e)
		{
			String server = comboBoxIP.Text;	// "10.5.10.18";
			String message = "SENTRY-T2-1,H0699232610-17331K1094,1,M009028,SENTRY,,OK,,";//詢問訊息。
			int port = int.Parse(comboBoxPort.Text);		// 21347;
			Connect(server, message, port);
		}
		void Connect(String server, String message, int port)
		{
			StringBuilder result = new StringBuilder();
			try
			{
				// Create a TcpClient.
				// Note, for this client to work you need to have a TcpServer 
				// connected to the same address as specified by the server, port
				// combination.
				//   Int32 port = 13000;
				TcpClient client = new TcpClient(server, port);
				//TcpClient client = new TcpClient("10.5.10.18", 21347);

				// Translate the passed message into ASCII and store it as a Byte array.
				//String message = "SENTRY-T2-1,H0699232610-17331K1094,1,M009028,SENTRY,,OK,,";//詢問訊息。
				Byte[] data = System.Text.Encoding.ASCII.GetBytes(message);

				// Get a client stream for reading and writing.
				//  Stream stream = client.GetStream();

				NetworkStream stream = client.GetStream();

				// Send the message to the connected TcpServer. 
				stream.Write(data, 0, data.Length);

				Console.WriteLine("Sent: {0}", message);
				//LogHelper.Log("Connect:" + message);
				result.Append("Connect:" + message);
				// Receive the TcpServer.response.

				// Buffer to store the response bytes.
				data = new Byte[256];

				// String to store the response ASCII representation.
				String responseData = String.Empty;

				// Read the first batch of the TcpServer response bytes.
				Int32 bytes = stream.Read(data, 0, data.Length);
				responseData = System.Text.Encoding.ASCII.GetString(data, 0, bytes);
				Console.WriteLine("Received: {0}", responseData);
				//LogHelper.Log("Received:" + responseData);
				result.Append("\r\nReceived: " + responseData);
				// Close everything.

				stream.Close();
				client.Close();
				//this.richTextBox1.Text += responseData + "\r\n";
			}
			catch (ArgumentNullException e)
			{
				//LogHelper.Log("connect" + e);
				result.Append("connect" + e);
				Console.WriteLine("ArgumentNullException: {0}", e);
				result.Append("ArgumentNullException: " + e);
			}
			labelServerStatus.Text = result.ToString();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			string stemp = ConfigSendData(IconType.okbutton);
			labelServerStatus.Text = stemp;
		}

		private void button2_Click(object sender, EventArgs e)
		{
			string stemp = ConfigSendData(IconType.submitbutton);
			labelServerStatus.Text = stemp;
		}

		private void robertTimerToolStripMenuItem_Click(object sender, EventArgs e)
		{
			robertTimerToolStripMenuItem.Checked = !robertTimerToolStripMenuItem.Checked;
			if (robertTimerToolStripMenuItem.Checked)
			{
				timerRobertArm.Start();
			}
			else
				timerRobertArm.Stop();
		}

		private void sendResultFToolStripMenuItem_Click(object sender, EventArgs e)
		{
			string spass = GetTestMessage();
			#region 客户端发送结果
			ShowResult("发送结果");
			//发送ready
			int msgType = NewMessageType.ClientSendTestFinished;
			MsgRequestContract contract = new MsgRequestContract("", "");
			//	contract.Msg = "barcode,OK";	//gBarcode + ",OK";	//barcode:gBarcode, result: OK/FAIL .
			string scode = "";
			if (gbChangeini)
				scode = gChangeini.ReadString("code", "Barcode", "*");
			else
				scode = gCodeini.ReadString("code", "Barcode", "*");
			scode = scode.ToUpper();
			//string spass = GetTestMessage();
			//if (spass != "PASS")
				spass = "FAIL";
			//發送條碼及測試結果，
			contract.Msg = scode + "," + spass;     //barcode:scode, result: PASS/FAIL .
			contract.Key = Guid.NewGuid().ToString();
			byte[] bBody = SerializeHelper.SerializeObject(contract);

			//消息头
			MessageHead head = new MessageHead(bBody.Length, msgType);
			byte[] bHead = head.ToStream();

			//构建请求消息
			byte[] reqMessage = new byte[bHead.Length + bBody.Length];
			Buffer.BlockCopy(bHead, 0, reqMessage, 0, bHead.Length);
			Buffer.BlockCopy(bBody, 0, reqMessage, bHead.Length, bBody.Length);

			//发送请求消息
			this.tcpPassiveEngine.PostMessageToServer(reqMessage);
			#endregion
		}

		private void timerPositionToolStripMenuItem_Click(object sender, EventArgs e)
		{
			timerPositionToolStripMenuItem.Checked = !timerPositionToolStripMenuItem.Checked;
			if (timerPositionToolStripMenuItem.Checked)
				timerPosition.Start();
			else
				timerPosition.Stop();
		}

		private string ConfigSendData(IconType icontype)
		{
			string stemp, sMAC, SendBarcodeOnly, spass;
			bool bSendBarcodeOnly;	//只送barcode資料
			int iMac, iloop;	//用在多個mac的資料
			string sMacTemp;
			//string result = "";
			stemp = "";
			stemp = labelFixtureID.Text + "," + gBarcode + ",";
			if ((gMACcode.Length < 12) && (gMACcode.Length > 3))
				sMAC = gCodeini.ReadString("control", "MACHead", "").Trim().ToUpper();
			else
				sMAC = gMACcode.ToUpper();
			//如果有多個MAC則要加以下判斷
			iMac = gCodeini.ReadInteger("control", "MultiMAC", 1);
			sMacTemp = "";
			if (iMac > 1)
			{
				for(iloop =1; iloop < iMac; iloop--)
				{
					string sloop = iloop.ToString();
					if (gbChangeini)
					{
						if (! gChangeini.ValueExists("MultiMAC", sloop))
						{
							MessageBox.Show("Multi MAC not Exist: " + sloop);
							//return false;
						}
						sMacTemp = sMacTemp + "MAC" + iloop + "=" + gChangeini.ReadString("MultiMAC", sloop, "error" + sloop);
					}
					else
					{
						if (! gCodeini.ValueExists("MultiMAC", iloop.ToString()))
						{
							MessageBox.Show("Multi MAC not Exist(code): " + sloop);
							//return "";
						}
						sMacTemp = sMacTemp + "MAC" + iloop + "=" + gCodeini.ReadString("MultiMAC", sloop, "error" + sloop);
					}
				}
			}	// iMac >1
			else
			{	// iMac <=1
				if (sMAC.Trim().Length != 0)
				{   //有mac資料才需要加MAC_CNT=1
					iMac = XStrings.Txstrings.CountWord(sMAC, "=");
					if (iMac > 1)
						if (!sMAC.Contains("OTHER"))
							if (!sMAC.Contains("MAC_CNT"))
								sMAC = sMAC + " MAC_CNT=" + (--iMac).ToString();
					else
						sMAC = "MAC1=" + sMAC + " " + "MAC_CNT=1";
				}
			}
			SendBarcodeOnly = gCodeini.ReadString("control", "SendBarcodeOnly", "OFF");
			if (SendBarcodeOnly == "ON")
				bSendBarcodeOnly = true;
			else
				bSendBarcodeOnly = false;
			switch (icontype)
			{
				case IconType.okbutton:
					if (!bSendBarcodeOnly)
					{
						if (gbChangeini)
							stemp = stemp + "1," + GetUserID() + "," + gChangeini.ReadString("Logfile", "ProductLine", "0") + "," +
								sMAC + ",OK," + gSSNcode + "," + gGuidcode + "," + gSN2code + "," + gMOcode;
						else
							stemp = stemp + "1," + GetUserID() + "," + gCodeini.ReadString("Logfile", "ProductLine", "0") + "," +
								sMAC + ",OK," + gSSNcode + "," + gGuidcode + "," + gSN2code + "," + gMOcode;
					}
					else
					{
						if (gbChangeini)
							stemp = stemp + "1," + GetUserID() + "," + gChangeini.ReadString("Logfile", "ProductLine", "0") + ",,OK,,";
						else
							stemp = stemp + "1," + GetUserID() + "," + gCodeini.ReadString("Logfile", "ProductLine", "0") + ",,OK,,";
					}
					break;
				case IconType.submitbutton:
					spass = GetTestMessage();
					if (spass == "")
					{
						MessageBox.Show("Get log file error.");
						EmptyBarcode();
						return "";
					}
					if (spass == "PASS")
					{   //Test result is pass
						if (!bSendBarcodeOnly)
						{
							if (gbChangeini)
								stemp = stemp + "2," + GetUserID() + "," + gChangeini.ReadString("Logfile", "ProductLine", "0") + "," +
									sMAC + ",OK," + gSSNcode + "," + gGuidcode + "," + gSN2code + "," + gMOcode;
							else
								stemp = stemp + "2," + GetUserID() + "," + gCodeini.ReadString("Logfile", "ProductLine", "0") + "," +
									sMAC + ",OK," + gSSNcode + "," + gGuidcode + "," + gSN2code + "," + gMOcode;
						}
						else
						{   //只傳送barcode
							if (gbChangeini)
								stemp = stemp + "2," + GetUserID() + "," + gChangeini.ReadString("Logfile", "ProductLine", "0") + ",,OK,,";
							else
								stemp = stemp + "2," + GetUserID() + "," + gCodeini.ReadString("Logfile", "ProductLine", "0") + ",,OK,,";
						}
					}
					else
					{	//Test result is fail
						if (!bSendBarcodeOnly)
						{
							if (gbChangeini)
								stemp = stemp + "2," + GetUserID() + "," + gChangeini.ReadString("Logfile", "ProductLine", "0") + "," +
									sMAC + ",FAIL," + gCodeini.ReadString("Logfile", "ErrorVersion", "0") + "," + spass;
							else
								stemp = stemp + GetUserID() + "," + gCodeini.ReadString("Logfile", "ProductLine", "0") + "," +
									sMAC + ",FAIL," + gCodeini.ReadString("Logfile", "ErrorVersion", "0") + "," + spass;
						}
						else
						{   //只傳送barcode
							if (gbChangeini)
								stemp = stemp + "2," + GetUserID() + "," + gChangeini.ReadString("Logfile", "ProductLine", "0") + ",,FAIL," +
									gCodeini.ReadString("Logfile", "ErrorVersion", "0") + "," + spass;
							else
								stemp = stemp + "2," + GetUserID() + "," + gCodeini.ReadString("Logfile", "ProductLine", "0") + ",,FAIL," +
									gCodeini.ReadString("Logfile", "ErrorVersion", "0") + "," + spass;
						}
					}
					break;
				default:
					return "";
			}
			return(stemp);
		}

		private string GetTestMessage()
		{
			//FileInfo filevar;
			string stemp, scode;
			//string sanser, scodetemp;
			string sfilepath;
			int itemp, icount, iloop, istop;
			var Items = new List<string>();

			string result = "";
			sfilepath = gCodeini.ReadString("Logfile", "LOGPATH", @"C:\MFT\LOG");
			sfilepath = sfilepath + @"\" + gCodeini.ReadString("Logfile", "Filename", "testlog.txt");
			if (!File.Exists(sfilepath))
			{
				SetLabelNetText("File not found: " + sfilepath);
				return ("");
			}
			stemp = "";
			if (gbChangeini)
				scode = gChangeini.ReadString("code", "Barcode", "*");
			else
				scode = gCodeini.ReadString("code", "Barcode", "*");
			scode = scode.ToUpper();
			Items.Clear();				//listBox2.Items.Clear();
			loadFromFile(sfilepath, Items); //由testLog.txt中得到測過的條碼。檢查最後10個序號找到符合的序號取得測試結果(pass/fail)
			icount = Items.Count;		// icount = listBox2.Items.Count;
			istop = icount - 10;
			if (istop < 0)
				istop = 0;
			for(iloop = icount-1; iloop>istop; iloop--)
			{
				//stemp = listBox2.Items[iloop].ToString().ToUpper();
				stemp = Items[iloop].ToString().ToUpper();
				if (CheckTestMessage(scode, stemp))
					break;
				stemp = "EXITEXIT";
			}
			stemp = stemp.ToUpper();
			SetLabelNetText("Send Result data to SFC");
			if (stemp.Contains("PASS"))
				return ("PASS");
			else
			{
				itemp = gCodeini.ReadInteger("Lofgile", "ErrorPos", 4);
				gsErrorData = "";
				if (XStrings.Txstrings.CountWord(stemp, ",") >= 7)
					gsErrorData = Txstrings.GetToken(stemp, 7, false, ",").Trim();
				result = Txstrings.GetToken(stemp, itemp, false, ",");
			}
			//this.Invoke(new MethodInvoker(() => { sendResultToolStripMenuItem.PerformClick(); })); //傳送條碼及結果給Robert。
			return (result);
		}
		private void loadFromFile(string filePath, List<string> items)
		{	//將TestLog.txt內容讀入。再檢查最後10個序號找到符合的序號取得測試結果(pass/fail)
			using (var reader = new System.IO.StreamReader(filePath))
			{
				string line;
				// read until no more lines are present
				while ((line = reader.ReadLine()) != null)
				{
					items.Add(line);
				}
			}
		}

		private bool CheckTestMessage(string sBarcode, string sTestList)
		{
			string stemp, smycode;
			int ihh, inn, inow, ilog, itemp, icount;
			//bool result = false;
			icount = Txstrings.CountWord(sTestList, ",");
			int shh = DateTime.Now.Hour;
			int snn = DateTime.Now.Minute;
			if (icount < 7)
				return (false);
			try
			{
				smycode = Txstrings.GetToken(sTestList, 1, false, ",");
				if (smycode == sBarcode)
				{	//當barcode相同，測試時間與目前小於1分鐘才可。
					inow = shh * 60 + snn;
					stemp = Txstrings.GetToken(sTestList, 6, false, ",");
					stemp = Txstrings.GetToken(stemp, 2, false, " ");
					ihh = int.Parse(Txstrings.GetToken(stemp, 1, false, ":"));
					inn = int.Parse(Txstrings.GetToken(stemp, 2, false, ":"));
					ilog = ihh * 60 + inn;
					itemp = inow - ilog;
					if ((itemp < 2) && (itemp > -2))
						return (true);
				}
			}
			catch { return (false); }
			return (true);
		}

		private string GetUserID()
		{
			if (gbChangeini)
				return (gChangeini.ReadString("code", "EMP_NO", "000"));
			else
				return (gCodeini.ReadString("code", "EMP_NO", "000"));
		}

		private bool FileCRC32Check()
		{
			string sFCTCRC, sDIOCRC, sComCRC, sBarcodeCRC, sVersionCRC, sBOMCRC;
			string TempList;
			string sFileName, stempCRC, stemp, sUperPath;
			TIniFile aVersion;
			//bool result = false;
			Tcrc Frdlock = new Tcrc();
			try
			{
				if (gCodeini.ValueExists("control", "RDID1"))
				{
					sFCTCRC = gCodeini.ReadString("control", "RDID1", "NON");
					sDIOCRC = gCodeini.ReadString("control", "RDID2", "NON");
					sComCRC = gCodeini.ReadString("control", "RDID3", "NON");
					sBarcodeCRC = gCodeini.ReadString("control", "RDID4", "NON");
					if ((sFCTCRC == "NON") || (sDIOCRC == "NON") || (sComCRC == "NON") || (sBarcodeCRC == "NON"))
						return false;
					sFileName = gFilePath + @"\fctcommand.txt";
					stempCRC = Frdlock.GetCRC32(sFileName);
					if (stempCRC != sFCTCRC)
					{
						MessageBox.Show("FCTCommand.txt CRC Error.");
						//return false;
					}
					sFileName = gFilePath + @"\dio.ini";
					stempCRC = Frdlock.GetCRC32(sFileName);
					if (stempCRC != sDIOCRC)
					{
						MessageBox.Show("DIO.ini CRC Error.");
						//return false;
					}
					sFileName = gFilePath + @"\COM.ini";
					stempCRC = Frdlock.GetCRC32(sFileName);
					if (stempCRC != sComCRC)
					{
						MessageBox.Show("Com.ini CRC Error.");
						//return false;
					}
					TempList = gCodeini.ReadCRCSection("Config");
					stempCRC = Frdlock.GetCRC32S(TempList);
					if (stempCRC != sBarcodeCRC)
					{
						MessageBox.Show("Barcode CRC Error.");
						//return false;
					}
					sUperPath = System.IO.Directory.GetParent(gFilePath).ToString();	//FCTCommand.txt的上一層目錄
					sFileName = sUperPath + @"\version.ini";	//version.ini的路徑				
					if (File.Exists(sFileName))
					{
						aVersion = new TIniFile(sFileName);
						sVersionCRC = aVersion.ReadString("number", "RDID5", "0");
						TempList = aVersion.ReadCRCSection("barcode");
						stempCRC = Frdlock.GetCRC32S(TempList);
						if (stempCRC != sVersionCRC)
						{
							MessageBox.Show("version.ini CRC Error.");
							//return false;
						}
					}
					sFileName = sUperPath+@"\SystemBOM.ini";	//systemBOM.ini的路徑
					if (File.Exists(sFileName))
					{
						aVersion = new TIniFile(sFileName);
						sBOMCRC = aVersion.ReadString("control", "RDID6", "0");
						TempList = aVersion.ReadCRCSection("config");
						stempCRC = Frdlock.GetCRC32S(TempList);
						if (stempCRC != sBOMCRC)
						{
							MessageBox.Show("systemBom.ini CRC Error.");
							//return false;
						}
					}
				}
			}
			catch { return false; }
			return true;
		}
		const int BYTES_TO_READ = sizeof(Int64);
		private int gSubmitNumber;
		private bool gbRestore = true;
		private ITcpPassiveEngine tcpPassiveEngine;

		static bool FilesAreEqual(FileInfo first, FileInfo second)
		{
			try
			{
				if (first.Length != second.Length)
					return false;

				if (string.Equals(first.FullName, second.FullName, StringComparison.OrdinalIgnoreCase))
					return true;

				int iterations = (int)Math.Ceiling((double)first.Length / BYTES_TO_READ);

				using (FileStream fs1 = first.OpenRead())
				using (FileStream fs2 = second.OpenRead())
				{
					byte[] one = new byte[BYTES_TO_READ];
					byte[] two = new byte[BYTES_TO_READ];

					for (int i = 0; i < iterations; i++)
					{
						fs1.Read(one, 0, BYTES_TO_READ);
						fs2.Read(two, 0, BYTES_TO_READ);

						if (BitConverter.ToInt64(one, 0) != BitConverter.ToInt64(two, 0))
							return false;
					}
				}
			}
			catch { return false; }
			
			return true;
		}
		private bool ServerFileCheck()
		{   //compare fctcommand.txt, dio.ini 是否相同於c:\usi\prod\
			string SourcePath, stempS, stempL;
			bool result;
			SourcePath = @"c:\usi\prod";
			stempS = SourcePath + @"\fctcommand.txt";
			stempL = gFilePath + @"\fctcommand.txt";
			result = FilesAreEqual(new FileInfo(stempS), new FileInfo(stempL));
			if (result)
			{
				stempS = SourcePath + @"\dio.ini";
				stempL = gFilePath + @"\dio.ini";
				return(FilesAreEqual(new FileInfo(stempS), new FileInfo(stempL)));
			}
			return false;
		}

		private bool OpenMainForm()
		{
			string RunPath, fileName, fileParameters;
			//IntPtr APHandle;
			//bool result = false;
			RunPath = Environment.CurrentDirectory;
			fileName = gCodeini.ReadString("control", "FCTEXEName", "PUSIGB.exe");
			fileParameters = gCodeini.ReadString("control", "FCTEXEParameters", " ");
			//if (RunPath[RunPath.Length - 1] != '\\')
			//	RunPath = RunPath + "\\";
			if (fileName.Contains("PUSIGB.exe"))
				RunPath = RunPath + @"\PUSIGB.exe";
			else
				RunPath = fileName;
			try
			{   //執行PUSIGB.exe
				//string RunPath, stemp;
				//Process APHandle = null;
				////RunPath = Environment.CurrentDirectory;         //Environment.CommandLine;
				////RunPath = RunPath + @"\Productver.exe";
				//this.WindowState = FormWindowState.Minimized;
				//APHandle = Process.Start(RunPath);
				//this.WindowState = FormWindowState.Normal;
				//APHandle = ShellExecute(IntPtr.Zero, "open", RunPath, fileParameters, 
				//	Environment.CurrentDirectory, (int)ShowWindowCommands.SW_HIDE);
				ProcessStartInfo cmdsi = new ProcessStartInfo();
				cmdsi.FileName = RunPath;
				cmdsi.Arguments = fileParameters;
				cmdsi.WorkingDirectory = Environment.CurrentDirectory;
				cmdsi.UseShellExecute = false;
				Process.Start(cmdsi).WaitForExit();
			}
			catch { MessageBox.Show("Run Error: " + RunPath); return false; }
			// if (APHandle<=32) Error
			return true;
		}

		private void BackupBarcode()
		{
			int iguid;
			if (gbChangeini)
				gChangeini.WriteString("restore", "barcode", textBoxBarcode.Text);
			else
				gCodeini.WriteString("resotre", "barcode", textBoxBarcode.Text);
			gBarcode = textBoxBarcode.Text;
			gMACcode = "";
			if (gbChangeini)
				gChangeini.WriteString("restore", "mac", textBoxMac.Text);
			else
				gCodeini.WriteString("restore", "mac", textBoxMac.Text);
			gMACcode = textBoxMac.Text;
			iguid = gCodeini.ReadInteger("control", "GUIDSaveTO", 0);
			switch (iguid)
			{
				case 3: gSSNcode = textBoxGuid.Text;	break;
				case 4: gSN2code = textBoxGuid.Text;	break;
				case 5: gMOcode = textBoxGuid.Text;		break;
				default: gGuidcode = textBoxGuid.Text;	break;
			}
			if (textBoxGuid.Enabled)
				if (gbChangeini)
					gChangeini.WriteString("restore", "guid", textBoxGuid.Text);
				else
					gCodeini.WriteString("restore", "guid", textBoxGuid.Text);
		}

		private bool DeviceAdd()
		{
			int itemp;
			try
			{
				itemp = gSymbolini.ReadInteger("DeviceCheck", "1", 0);
				itemp += 1;
				gSymbolini.WriteInteger("DeviceCheck", "1", itemp);
			}
			catch { return false; }
			return true;
		}
		private bool DeviceCheck()
		{
			int imax, itemp;
			imax = gSymbolini.ReadInteger("DeviceCheck", "0", 100);
			itemp = gSymbolini.ReadInteger("DeviceCheck", "1", 100);
			labelPath.Text = "Max:" + imax + ", Counter:" + itemp;
			if (itemp >= imax)
			{
				MessageBox.Show("Renew Device Please. " + itemp + "," + imax);
				return false;
			}
			return true;
		}

		private void debugFlagToolStripMenuItem_Click(object sender, EventArgs e)
		{
			debugFlagToolStripMenuItem.Checked = !debugFlagToolStripMenuItem.Checked;
			if (debugFlagToolStripMenuItem.Checked)
			{
				this.Width = 890;
			}
			else
				this.Width = 530;
		}
	}
}
