﻿namespace BarcodeForm
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
			this.textBoxGuid = new System.Windows.Forms.TextBox();
			this.textBoxMac = new System.Windows.Forms.TextBox();
			this.textBoxBarcode = new System.Windows.Forms.TextBox();
			this.textBoxConfig = new System.Windows.Forms.TextBox();
			this.buttonOK = new System.Windows.Forms.Button();
			this.buttonClose = new System.Windows.Forms.Button();
			this.buttonLogout = new System.Windows.Forms.Button();
			this.buttonSubmit = new System.Windows.Forms.Button();
			this.buttonRetest = new System.Windows.Forms.Button();
			this.labelID = new System.Windows.Forms.Label();
			this.labelPath = new System.Windows.Forms.Label();
			this.labelGuid = new System.Windows.Forms.Label();
			this.labelMac = new System.Windows.Forms.Label();
			this.labelBarcode = new System.Windows.Forms.Label();
			this.labelConfig = new System.Windows.Forms.Label();
			this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.restoreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.labelNet = new System.Windows.Forms.Label();
			this.menuStrip1 = new System.Windows.Forms.MenuStrip();
			this.testToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.connectServerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.connectCloseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.sendServerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.debugMessageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.byteTestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.debugFlagToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.barcodeOKToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.barcodeAutoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.barcodeOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.barcodeLoopToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.loopingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.timerRobertToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.timerPositionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.looping50ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.looping100ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.robertToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.armConnectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.serialPortToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.robertTimerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.serverToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.connectServerToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			this.sendReadyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.sendResultToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.closeConnectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.updateBarcodeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.testUpdateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.contineServerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.connectSFISServerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.sendResultFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.labelFixtureID = new System.Windows.Forms.Label();
			this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.rDTestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.timerClose = new System.Windows.Forms.Timer(this.components);
			this.timerFind = new System.Windows.Forms.Timer(this.components);
			this.timerToHost = new System.Windows.Forms.Timer(this.components);
			this.listBox2 = new System.Windows.Forms.ListBox();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.timerRobertArm = new System.Windows.Forms.Timer(this.components);
			this.timerPosition = new System.Windows.Forms.Timer(this.components);
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.comboBoxPort = new System.Windows.Forms.ComboBox();
			this.comboBoxIP = new System.Windows.Forms.ComboBox();
			this.labelServerStatus = new System.Windows.Forms.Label();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.button2 = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.label4 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.menuStrip1.SuspendLayout();
			this.contextMenuStrip1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.tabControl1.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.tabPage2.SuspendLayout();
			this.SuspendLayout();
			// 
			// textBoxGuid
			// 
			this.textBoxGuid.Enabled = false;
			this.textBoxGuid.Location = new System.Drawing.Point(79, 106);
			this.textBoxGuid.Name = "textBoxGuid";
			this.textBoxGuid.Size = new System.Drawing.Size(269, 22);
			this.textBoxGuid.TabIndex = 33;
			// 
			// textBoxMac
			// 
			this.textBoxMac.Enabled = false;
			this.textBoxMac.Location = new System.Drawing.Point(79, 78);
			this.textBoxMac.Name = "textBoxMac";
			this.textBoxMac.Size = new System.Drawing.Size(269, 22);
			this.textBoxMac.TabIndex = 32;
			// 
			// textBoxBarcode
			// 
			this.textBoxBarcode.Location = new System.Drawing.Point(79, 50);
			this.textBoxBarcode.Name = "textBoxBarcode";
			this.textBoxBarcode.Size = new System.Drawing.Size(269, 22);
			this.textBoxBarcode.TabIndex = 31;
			this.textBoxBarcode.TextChanged += new System.EventHandler(this.textBoxBarcode_TextChanged);
			this.textBoxBarcode.KeyUp += new System.Windows.Forms.KeyEventHandler(this.textBoxBarcode_KeyUp);
			this.textBoxBarcode.Leave += new System.EventHandler(this.textBoxBarcode_Leave);
			// 
			// textBoxConfig
			// 
			this.textBoxConfig.Location = new System.Drawing.Point(79, 22);
			this.textBoxConfig.Name = "textBoxConfig";
			this.textBoxConfig.Size = new System.Drawing.Size(269, 22);
			this.textBoxConfig.TabIndex = 30;
			// 
			// buttonOK
			// 
			this.buttonOK.Enabled = false;
			this.buttonOK.Location = new System.Drawing.Point(362, 83);
			this.buttonOK.Name = "buttonOK";
			this.buttonOK.Size = new System.Drawing.Size(75, 45);
			this.buttonOK.TabIndex = 29;
			this.buttonOK.Text = "OK";
			this.buttonOK.UseVisualStyleBackColor = true;
			this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
			// 
			// buttonClose
			// 
			this.buttonClose.Location = new System.Drawing.Point(249, 254);
			this.buttonClose.Name = "buttonClose";
			this.buttonClose.Size = new System.Drawing.Size(93, 41);
			this.buttonClose.TabIndex = 28;
			this.buttonClose.Text = "CLOSE";
			this.buttonClose.UseVisualStyleBackColor = true;
			this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
			// 
			// buttonLogout
			// 
			this.buttonLogout.Location = new System.Drawing.Point(87, 254);
			this.buttonLogout.Name = "buttonLogout";
			this.buttonLogout.Size = new System.Drawing.Size(93, 41);
			this.buttonLogout.TabIndex = 27;
			this.buttonLogout.Text = "LOGOUT";
			this.buttonLogout.UseVisualStyleBackColor = true;
			this.buttonLogout.Click += new System.EventHandler(this.buttonLogout_Click);
			// 
			// buttonSubmit
			// 
			this.buttonSubmit.Enabled = false;
			this.buttonSubmit.Location = new System.Drawing.Point(249, 206);
			this.buttonSubmit.Name = "buttonSubmit";
			this.buttonSubmit.Size = new System.Drawing.Size(93, 41);
			this.buttonSubmit.TabIndex = 26;
			this.buttonSubmit.Text = "SUBMIT";
			this.buttonSubmit.UseVisualStyleBackColor = true;
			this.buttonSubmit.Click += new System.EventHandler(this.buttonSubmit_Click);
			// 
			// buttonRetest
			// 
			this.buttonRetest.Enabled = false;
			this.buttonRetest.Location = new System.Drawing.Point(87, 207);
			this.buttonRetest.Name = "buttonRetest";
			this.buttonRetest.Size = new System.Drawing.Size(93, 41);
			this.buttonRetest.TabIndex = 25;
			this.buttonRetest.Text = "RETEST";
			this.buttonRetest.UseVisualStyleBackColor = true;
			this.buttonRetest.Click += new System.EventHandler(this.buttonRetest_Click);
			// 
			// labelID
			// 
			this.labelID.AutoSize = true;
			this.labelID.Location = new System.Drawing.Point(365, 8);
			this.labelID.Name = "labelID";
			this.labelID.Size = new System.Drawing.Size(20, 12);
			this.labelID.TabIndex = 24;
			this.labelID.Text = "ID:";
			// 
			// labelPath
			// 
			this.labelPath.AutoSize = true;
			this.labelPath.Location = new System.Drawing.Point(18, 189);
			this.labelPath.Name = "labelPath";
			this.labelPath.Size = new System.Drawing.Size(47, 12);
			this.labelPath.TabIndex = 23;
			this.labelPath.Text = "labelPath";
			// 
			// labelGuid
			// 
			this.labelGuid.AutoSize = true;
			this.labelGuid.Location = new System.Drawing.Point(18, 111);
			this.labelGuid.Name = "labelGuid";
			this.labelGuid.Size = new System.Drawing.Size(56, 12);
			this.labelGuid.TabIndex = 21;
			this.labelGuid.Text = "Extra Info:";
			// 
			// labelMac
			// 
			this.labelMac.AutoSize = true;
			this.labelMac.Location = new System.Drawing.Point(18, 83);
			this.labelMac.Name = "labelMac";
			this.labelMac.Size = new System.Drawing.Size(56, 12);
			this.labelMac.TabIndex = 20;
			this.labelMac.Text = "MACcode:";
			// 
			// labelBarcode
			// 
			this.labelBarcode.AutoSize = true;
			this.labelBarcode.Location = new System.Drawing.Point(18, 55);
			this.labelBarcode.Name = "labelBarcode";
			this.labelBarcode.Size = new System.Drawing.Size(47, 12);
			this.labelBarcode.TabIndex = 19;
			this.labelBarcode.Text = "Barcode:";
			// 
			// labelConfig
			// 
			this.labelConfig.AutoSize = true;
			this.labelConfig.Location = new System.Drawing.Point(18, 26);
			this.labelConfig.Name = "labelConfig";
			this.labelConfig.Size = new System.Drawing.Size(41, 12);
			this.labelConfig.TabIndex = 18;
			this.labelConfig.Text = "Config:";
			// 
			// helpToolStripMenuItem
			// 
			this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
			this.helpToolStripMenuItem.Size = new System.Drawing.Size(47, 20);
			this.helpToolStripMenuItem.Text = "Help";
			this.helpToolStripMenuItem.Click += new System.EventHandler(this.helpToolStripMenuItem_Click);
			// 
			// restoreToolStripMenuItem
			// 
			this.restoreToolStripMenuItem.Name = "restoreToolStripMenuItem";
			this.restoreToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
			this.restoreToolStripMenuItem.Text = "Restore";
			this.restoreToolStripMenuItem.Click += new System.EventHandler(this.restoreToolStripMenuItem_Click);
			// 
			// fileToolStripMenuItem
			// 
			this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.restoreToolStripMenuItem});
			this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
			this.fileToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
			this.fileToolStripMenuItem.Text = "File";
			// 
			// labelNet
			// 
			this.labelNet.AutoSize = true;
			this.labelNet.Font = new System.Drawing.Font("PMingLiU", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
			this.labelNet.ForeColor = System.Drawing.Color.Red;
			this.labelNet.Location = new System.Drawing.Point(18, 132);
			this.labelNet.Name = "labelNet";
			this.labelNet.Size = new System.Drawing.Size(70, 19);
			this.labelNet.TabIndex = 22;
			this.labelNet.Text = "labelNet";
			// 
			// menuStrip1
			// 
			this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.helpToolStripMenuItem,
            this.testToolStripMenuItem,
            this.robertToolStripMenuItem,
            this.serverToolStripMenuItem});
			this.menuStrip1.Location = new System.Drawing.Point(0, 0);
			this.menuStrip1.Name = "menuStrip1";
			this.menuStrip1.Size = new System.Drawing.Size(632, 24);
			this.menuStrip1.TabIndex = 17;
			this.menuStrip1.Text = "menuStrip1";
			// 
			// testToolStripMenuItem
			// 
			this.testToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.connectServerToolStripMenuItem,
            this.connectCloseToolStripMenuItem,
            this.sendServerToolStripMenuItem,
            this.debugMessageToolStripMenuItem,
            this.byteTestToolStripMenuItem,
            this.debugFlagToolStripMenuItem,
            this.barcodeOKToolStripMenuItem,
            this.barcodeAutoToolStripMenuItem,
            this.barcodeOToolStripMenuItem,
            this.barcodeLoopToolStripMenuItem,
            this.loopingToolStripMenuItem,
            this.timerRobertToolStripMenuItem,
            this.timerPositionToolStripMenuItem,
            this.looping50ToolStripMenuItem,
            this.looping100ToolStripMenuItem});
			this.testToolStripMenuItem.Name = "testToolStripMenuItem";
			this.testToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
			this.testToolStripMenuItem.Text = "Test";
			// 
			// connectServerToolStripMenuItem
			// 
			this.connectServerToolStripMenuItem.Name = "connectServerToolStripMenuItem";
			this.connectServerToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
			this.connectServerToolStripMenuItem.Text = "ConnectServer";
			this.connectServerToolStripMenuItem.Click += new System.EventHandler(this.connectServerToolStripMenuItem_Click);
			// 
			// connectCloseToolStripMenuItem
			// 
			this.connectCloseToolStripMenuItem.Name = "connectCloseToolStripMenuItem";
			this.connectCloseToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
			this.connectCloseToolStripMenuItem.Text = "ConnectClose";
			this.connectCloseToolStripMenuItem.Click += new System.EventHandler(this.connectCloseToolStripMenuItem_Click);
			// 
			// sendServerToolStripMenuItem
			// 
			this.sendServerToolStripMenuItem.Name = "sendServerToolStripMenuItem";
			this.sendServerToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
			this.sendServerToolStripMenuItem.Text = "SendServer";
			this.sendServerToolStripMenuItem.Click += new System.EventHandler(this.sendServerToolStripMenuItem_Click);
			// 
			// debugMessageToolStripMenuItem
			// 
			this.debugMessageToolStripMenuItem.Name = "debugMessageToolStripMenuItem";
			this.debugMessageToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
			this.debugMessageToolStripMenuItem.Text = "DebugMessage";
			this.debugMessageToolStripMenuItem.Click += new System.EventHandler(this.debugMessageToolStripMenuItem_Click);
			// 
			// byteTestToolStripMenuItem
			// 
			this.byteTestToolStripMenuItem.Name = "byteTestToolStripMenuItem";
			this.byteTestToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
			this.byteTestToolStripMenuItem.Text = "ByteTest";
			this.byteTestToolStripMenuItem.Click += new System.EventHandler(this.byteTestToolStripMenuItem_Click);
			// 
			// debugFlagToolStripMenuItem
			// 
			this.debugFlagToolStripMenuItem.Name = "debugFlagToolStripMenuItem";
			this.debugFlagToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
			this.debugFlagToolStripMenuItem.Text = "DebugFlag";
			this.debugFlagToolStripMenuItem.Click += new System.EventHandler(this.debugFlagToolStripMenuItem_Click);
			// 
			// barcodeOKToolStripMenuItem
			// 
			this.barcodeOKToolStripMenuItem.Name = "barcodeOKToolStripMenuItem";
			this.barcodeOKToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
			this.barcodeOKToolStripMenuItem.Text = "BarcodeOK";
			this.barcodeOKToolStripMenuItem.Click += new System.EventHandler(this.barcodeOKToolStripMenuItem_Click);
			// 
			// barcodeAutoToolStripMenuItem
			// 
			this.barcodeAutoToolStripMenuItem.Name = "barcodeAutoToolStripMenuItem";
			this.barcodeAutoToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
			this.barcodeAutoToolStripMenuItem.Text = "BarcodeAuto";
			this.barcodeAutoToolStripMenuItem.Click += new System.EventHandler(this.barcodeAutoToolStripMenuItem_Click);
			// 
			// barcodeOToolStripMenuItem
			// 
			this.barcodeOToolStripMenuItem.Name = "barcodeOToolStripMenuItem";
			this.barcodeOToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
			this.barcodeOToolStripMenuItem.Text = "BarcodeO";
			this.barcodeOToolStripMenuItem.Click += new System.EventHandler(this.barcodeOToolStripMenuItem_Click);
			// 
			// barcodeLoopToolStripMenuItem
			// 
			this.barcodeLoopToolStripMenuItem.Name = "barcodeLoopToolStripMenuItem";
			this.barcodeLoopToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
			this.barcodeLoopToolStripMenuItem.Text = "BarcodeLoop";
			this.barcodeLoopToolStripMenuItem.Click += new System.EventHandler(this.barcodeLoopToolStripMenuItem_Click);
			// 
			// loopingToolStripMenuItem
			// 
			this.loopingToolStripMenuItem.Name = "loopingToolStripMenuItem";
			this.loopingToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
			this.loopingToolStripMenuItem.Text = "Looping 20";
			this.loopingToolStripMenuItem.Click += new System.EventHandler(this.loopingToolStripMenuItem_Click);
			// 
			// timerRobertToolStripMenuItem
			// 
			this.timerRobertToolStripMenuItem.Name = "timerRobertToolStripMenuItem";
			this.timerRobertToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
			this.timerRobertToolStripMenuItem.Text = "TimerRobert";
			this.timerRobertToolStripMenuItem.Click += new System.EventHandler(this.timerRobertToolStripMenuItem_Click);
			// 
			// timerPositionToolStripMenuItem
			// 
			this.timerPositionToolStripMenuItem.Name = "timerPositionToolStripMenuItem";
			this.timerPositionToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
			this.timerPositionToolStripMenuItem.Text = "TimerPosition";
			this.timerPositionToolStripMenuItem.Click += new System.EventHandler(this.timerPositionToolStripMenuItem_Click);
			// 
			// looping50ToolStripMenuItem
			// 
			this.looping50ToolStripMenuItem.Name = "looping50ToolStripMenuItem";
			this.looping50ToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
			this.looping50ToolStripMenuItem.Text = "Looping 50";
			this.looping50ToolStripMenuItem.Click += new System.EventHandler(this.looping50ToolStripMenuItem_Click);
			// 
			// looping100ToolStripMenuItem
			// 
			this.looping100ToolStripMenuItem.Name = "looping100ToolStripMenuItem";
			this.looping100ToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
			this.looping100ToolStripMenuItem.Text = "Looping 100";
			this.looping100ToolStripMenuItem.Click += new System.EventHandler(this.looping100ToolStripMenuItem_Click);
			// 
			// robertToolStripMenuItem
			// 
			this.robertToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.armConnectToolStripMenuItem,
            this.serialPortToolStripMenuItem,
            this.robertTimerToolStripMenuItem});
			this.robertToolStripMenuItem.Name = "robertToolStripMenuItem";
			this.robertToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
			this.robertToolStripMenuItem.Text = "Robert";
			// 
			// armConnectToolStripMenuItem
			// 
			this.armConnectToolStripMenuItem.Name = "armConnectToolStripMenuItem";
			this.armConnectToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
			this.armConnectToolStripMenuItem.Text = "ArmConnect";
			this.armConnectToolStripMenuItem.Click += new System.EventHandler(this.armConnectToolStripMenuItem_Click);
			// 
			// serialPortToolStripMenuItem
			// 
			this.serialPortToolStripMenuItem.Name = "serialPortToolStripMenuItem";
			this.serialPortToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
			this.serialPortToolStripMenuItem.Text = "SerialPort";
			this.serialPortToolStripMenuItem.Click += new System.EventHandler(this.serialPortToolStripMenuItem_Click);
			// 
			// robertTimerToolStripMenuItem
			// 
			this.robertTimerToolStripMenuItem.Name = "robertTimerToolStripMenuItem";
			this.robertTimerToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
			this.robertTimerToolStripMenuItem.Text = "RobertTimer";
			this.robertTimerToolStripMenuItem.Click += new System.EventHandler(this.robertTimerToolStripMenuItem_Click);
			// 
			// serverToolStripMenuItem
			// 
			this.serverToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.connectServerToolStripMenuItem1,
            this.sendReadyToolStripMenuItem,
            this.sendResultToolStripMenuItem,
            this.closeConnectToolStripMenuItem,
            this.updateBarcodeToolStripMenuItem,
            this.testUpdateToolStripMenuItem,
            this.contineServerToolStripMenuItem,
            this.connectSFISServerToolStripMenuItem,
            this.sendResultFToolStripMenuItem});
			this.serverToolStripMenuItem.Name = "serverToolStripMenuItem";
			this.serverToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
			this.serverToolStripMenuItem.Text = "Server";
			// 
			// connectServerToolStripMenuItem1
			// 
			this.connectServerToolStripMenuItem1.Name = "connectServerToolStripMenuItem1";
			this.connectServerToolStripMenuItem1.Size = new System.Drawing.Size(187, 22);
			this.connectServerToolStripMenuItem1.Text = "Connect Server";
			this.connectServerToolStripMenuItem1.Click += new System.EventHandler(this.connectServerToolStripMenuItem1_Click);
			// 
			// sendReadyToolStripMenuItem
			// 
			this.sendReadyToolStripMenuItem.Name = "sendReadyToolStripMenuItem";
			this.sendReadyToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
			this.sendReadyToolStripMenuItem.Text = "Send Ready";
			this.sendReadyToolStripMenuItem.Click += new System.EventHandler(this.sendReadyToolStripMenuItem_Click);
			// 
			// sendResultToolStripMenuItem
			// 
			this.sendResultToolStripMenuItem.Name = "sendResultToolStripMenuItem";
			this.sendResultToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
			this.sendResultToolStripMenuItem.Text = "Send Result";
			this.sendResultToolStripMenuItem.Click += new System.EventHandler(this.sendResultToolStripMenuItem_Click);
			// 
			// closeConnectToolStripMenuItem
			// 
			this.closeConnectToolStripMenuItem.Name = "closeConnectToolStripMenuItem";
			this.closeConnectToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
			this.closeConnectToolStripMenuItem.Text = "Close Connect";
			this.closeConnectToolStripMenuItem.Click += new System.EventHandler(this.closeConnectToolStripMenuItem_Click);
			// 
			// updateBarcodeToolStripMenuItem
			// 
			this.updateBarcodeToolStripMenuItem.Name = "updateBarcodeToolStripMenuItem";
			this.updateBarcodeToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
			this.updateBarcodeToolStripMenuItem.Text = "update Barcode";
			this.updateBarcodeToolStripMenuItem.Click += new System.EventHandler(this.updateBarcodeToolStripMenuItem_Click);
			// 
			// testUpdateToolStripMenuItem
			// 
			this.testUpdateToolStripMenuItem.Name = "testUpdateToolStripMenuItem";
			this.testUpdateToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
			this.testUpdateToolStripMenuItem.Text = "test update";
			this.testUpdateToolStripMenuItem.Click += new System.EventHandler(this.testUpdateToolStripMenuItem_Click);
			// 
			// contineServerToolStripMenuItem
			// 
			this.contineServerToolStripMenuItem.Name = "contineServerToolStripMenuItem";
			this.contineServerToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
			this.contineServerToolStripMenuItem.Text = "Contine Server";
			this.contineServerToolStripMenuItem.Click += new System.EventHandler(this.contineServerToolStripMenuItem_Click);
			// 
			// connectSFISServerToolStripMenuItem
			// 
			this.connectSFISServerToolStripMenuItem.Name = "connectSFISServerToolStripMenuItem";
			this.connectSFISServerToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
			this.connectSFISServerToolStripMenuItem.Text = "Connect SFIS Server";
			this.connectSFISServerToolStripMenuItem.Click += new System.EventHandler(this.connectSFISServerToolStripMenuItem_Click);
			// 
			// sendResultFToolStripMenuItem
			// 
			this.sendResultFToolStripMenuItem.Name = "sendResultFToolStripMenuItem";
			this.sendResultFToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
			this.sendResultFToolStripMenuItem.Text = "Send Result Fail";
			this.sendResultFToolStripMenuItem.Click += new System.EventHandler(this.sendResultFToolStripMenuItem_Click);
			// 
			// labelFixtureID
			// 
			this.labelFixtureID.AutoSize = true;
			this.labelFixtureID.Location = new System.Drawing.Point(366, 22);
			this.labelFixtureID.Name = "labelFixtureID";
			this.labelFixtureID.Size = new System.Drawing.Size(72, 12);
			this.labelFixtureID.TabIndex = 34;
			this.labelFixtureID.Text = "labelFixtureID";
			// 
			// contextMenuStrip1
			// 
			this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rDTestToolStripMenuItem});
			this.contextMenuStrip1.Name = "contextMenuStrip1";
			this.contextMenuStrip1.Size = new System.Drawing.Size(117, 26);
			// 
			// rDTestToolStripMenuItem
			// 
			this.rDTestToolStripMenuItem.Name = "rDTestToolStripMenuItem";
			this.rDTestToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
			this.rDTestToolStripMenuItem.Text = "RDTest";
			this.rDTestToolStripMenuItem.Click += new System.EventHandler(this.rDTestToolStripMenuItem_Click);
			// 
			// timerClose
			// 
			this.timerClose.Interval = 10000;
			this.timerClose.Tag = "";
			this.timerClose.Tick += new System.EventHandler(this.timerClose_Tick);
			// 
			// timerFind
			// 
			this.timerFind.Interval = 3000;
			this.timerFind.Tick += new System.EventHandler(this.timerFind_Tick);
			// 
			// timerToHost
			// 
			this.timerToHost.Tick += new System.EventHandler(this.timerToHost_Tick);
			// 
			// listBox2
			// 
			this.listBox2.FormattingEnabled = true;
			this.listBox2.ItemHeight = 12;
			this.listBox2.Location = new System.Drawing.Point(362, 132);
			this.listBox2.Name = "listBox2";
			this.listBox2.Size = new System.Drawing.Size(152, 88);
			this.listBox2.TabIndex = 36;
			this.listBox2.Visible = false;
			// 
			// pictureBox1
			// 
			this.pictureBox1.Location = new System.Drawing.Point(18, 153);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(100, 25);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox1.TabIndex = 37;
			this.pictureBox1.TabStop = false;
			// 
			// timerRobertArm
			// 
			this.timerRobertArm.Enabled = true;
			this.timerRobertArm.Interval = 4000;
			this.timerRobertArm.Tick += new System.EventHandler(this.timerRobertArm_Tick);
			// 
			// timerPosition
			// 
			this.timerPosition.Tick += new System.EventHandler(this.timerPosition_Tick);
			// 
			// tabControl1
			// 
			this.tabControl1.Controls.Add(this.tabPage1);
			this.tabControl1.Controls.Add(this.tabPage2);
			this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tabControl1.Location = new System.Drawing.Point(0, 24);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(632, 412);
			this.tabControl1.TabIndex = 48;
			// 
			// tabPage1
			// 
			this.tabPage1.Controls.Add(this.comboBoxPort);
			this.tabPage1.Controls.Add(this.comboBoxIP);
			this.tabPage1.Controls.Add(this.labelServerStatus);
			this.tabPage1.Controls.Add(this.buttonRetest);
			this.tabPage1.Controls.Add(this.labelNet);
			this.tabPage1.Controls.Add(this.labelConfig);
			this.tabPage1.Controls.Add(this.labelBarcode);
			this.tabPage1.Controls.Add(this.labelMac);
			this.tabPage1.Controls.Add(this.labelGuid);
			this.tabPage1.Controls.Add(this.labelPath);
			this.tabPage1.Controls.Add(this.labelID);
			this.tabPage1.Controls.Add(this.buttonSubmit);
			this.tabPage1.Controls.Add(this.buttonLogout);
			this.tabPage1.Controls.Add(this.pictureBox1);
			this.tabPage1.Controls.Add(this.buttonClose);
			this.tabPage1.Controls.Add(this.listBox2);
			this.tabPage1.Controls.Add(this.buttonOK);
			this.tabPage1.Controls.Add(this.labelFixtureID);
			this.tabPage1.Controls.Add(this.textBoxConfig);
			this.tabPage1.Controls.Add(this.textBoxGuid);
			this.tabPage1.Controls.Add(this.textBoxBarcode);
			this.tabPage1.Controls.Add(this.textBoxMac);
			this.tabPage1.Location = new System.Drawing.Point(4, 22);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage1.Size = new System.Drawing.Size(624, 386);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "PBarcodeF";
			this.tabPage1.UseVisualStyleBackColor = true;
			// 
			// comboBoxPort
			// 
			this.comboBoxPort.FormattingEnabled = true;
			this.comboBoxPort.Items.AddRange(new object[] {
            "9000",
            "21347"});
			this.comboBoxPort.Location = new System.Drawing.Point(362, 297);
			this.comboBoxPort.Name = "comboBoxPort";
			this.comboBoxPort.Size = new System.Drawing.Size(121, 20);
			this.comboBoxPort.TabIndex = 56;
			// 
			// comboBoxIP
			// 
			this.comboBoxIP.FormattingEnabled = true;
			this.comboBoxIP.Items.AddRange(new object[] {
            "127.0.0.1",
            "10.5.33.114",
            "192.168.124.63",
            "192.168.43.44",
            "10.5.10.18"});
			this.comboBoxIP.Location = new System.Drawing.Point(362, 273);
			this.comboBoxIP.Name = "comboBoxIP";
			this.comboBoxIP.Size = new System.Drawing.Size(152, 20);
			this.comboBoxIP.TabIndex = 55;
			// 
			// labelServerStatus
			// 
			this.labelServerStatus.AutoSize = true;
			this.labelServerStatus.Location = new System.Drawing.Point(362, 320);
			this.labelServerStatus.Name = "labelServerStatus";
			this.labelServerStatus.Size = new System.Drawing.Size(84, 12);
			this.labelServerStatus.TabIndex = 54;
			this.labelServerStatus.Text = "labelServerStatus";
			// 
			// tabPage2
			// 
			this.tabPage2.Controls.Add(this.button2);
			this.tabPage2.Controls.Add(this.button1);
			this.tabPage2.Controls.Add(this.comboBox1);
			this.tabPage2.Controls.Add(this.label4);
			this.tabPage2.Controls.Add(this.label3);
			this.tabPage2.Controls.Add(this.label2);
			this.tabPage2.Controls.Add(this.label1);
			this.tabPage2.Location = new System.Drawing.Point(4, 22);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage2.Size = new System.Drawing.Size(624, 386);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "Robert";
			this.tabPage2.UseVisualStyleBackColor = true;
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(354, 238);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(75, 23);
			this.button2.TabIndex = 55;
			this.button2.Text = "button2";
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(272, 238);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(75, 23);
			this.button1.TabIndex = 54;
			this.button1.Text = "button1";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// comboBox1
			// 
			this.comboBox1.FormattingEnabled = true;
			this.comboBox1.Items.AddRange(new object[] {
            "H0699232610-1234567890",
            "H0699361010-1234567890",
            "H0699512310-1234567890",
            "H0699842310-1234567890",
            "K0591841570-18284K0001",
            "H0699232610-17331K0006"});
			this.comboBox1.Location = new System.Drawing.Point(270, 106);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(164, 20);
			this.comboBox1.TabIndex = 51;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(4, 180);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(229, 12);
			this.label4.TabIndex = 49;
			this.label4.Text = "H0699232610-1234567890, R-46-camera-965 ";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(4, 164);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(213, 12);
			this.label3.TabIndex = 48;
			this.label3.Text = "H0699361010-1234567890, S-29-4750(45)";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(4, 148);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(233, 12);
			this.label2.TabIndex = 47;
			this.label2.Text = "H0699512310-1234567890, S-38-camera-4750 ";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(4, 134);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(198, 12);
			this.label1.TabIndex = 46;
			this.label1.Text = "H0699842310-1234567890, G-38-4850 ";
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(632, 436);
			this.ContextMenuStrip = this.contextMenuStrip1;
			this.Controls.Add(this.tabControl1);
			this.Controls.Add(this.menuStrip1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "Form1";
			this.Text = "USI PBarcode Form";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
			this.menuStrip1.ResumeLayout(false);
			this.menuStrip1.PerformLayout();
			this.contextMenuStrip1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.tabControl1.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			this.tabPage1.PerformLayout();
			this.tabPage2.ResumeLayout(false);
			this.tabPage2.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox textBoxGuid;
		private System.Windows.Forms.TextBox textBoxMac;
		private System.Windows.Forms.TextBox textBoxBarcode;
		private System.Windows.Forms.TextBox textBoxConfig;
		private System.Windows.Forms.Button buttonOK;
		private System.Windows.Forms.Button buttonClose;
		private System.Windows.Forms.Button buttonLogout;
		private System.Windows.Forms.Button buttonSubmit;
		private System.Windows.Forms.Button buttonRetest;
		private System.Windows.Forms.Label labelID;
		private System.Windows.Forms.Label labelPath;
		private System.Windows.Forms.Label labelGuid;
		private System.Windows.Forms.Label labelMac;
		private System.Windows.Forms.Label labelBarcode;
		private System.Windows.Forms.Label labelConfig;
		private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem restoreToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
		private System.Windows.Forms.Label labelNet;
		private System.Windows.Forms.MenuStrip menuStrip1;
		private System.Windows.Forms.ToolStripMenuItem testToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem connectServerToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem sendServerToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem debugMessageToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem byteTestToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem connectCloseToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem debugFlagToolStripMenuItem;
		private System.Windows.Forms.Label labelFixtureID;
		private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
		private System.Windows.Forms.Timer timerClose;
		private System.Windows.Forms.Timer timerFind;
		private System.Windows.Forms.Timer timerToHost;
		private System.Windows.Forms.ListBox listBox2;
		private System.Windows.Forms.ToolStripMenuItem rDTestToolStripMenuItem;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.ToolStripMenuItem barcodeOKToolStripMenuItem;
		private System.Windows.Forms.Timer timerRobertArm;
		private System.Windows.Forms.ToolStripMenuItem barcodeAutoToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem barcodeOToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem barcodeLoopToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem loopingToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem timerRobertToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem robertToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem armConnectToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem serialPortToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem timerPositionToolStripMenuItem;
		private System.Windows.Forms.Timer timerPosition;
		private System.Windows.Forms.ToolStripMenuItem serverToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem connectServerToolStripMenuItem1;
		private System.Windows.Forms.ToolStripMenuItem sendReadyToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem sendResultToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem closeConnectToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem looping50ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem looping100ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem updateBarcodeToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem testUpdateToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem contineServerToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem connectSFISServerToolStripMenuItem;
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.ComboBox comboBox1;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.ToolStripMenuItem robertTimerToolStripMenuItem;
		private System.Windows.Forms.ComboBox comboBoxPort;
		private System.Windows.Forms.ComboBox comboBoxIP;
		private System.Windows.Forms.Label labelServerStatus;
		private System.Windows.Forms.ToolStripMenuItem sendResultFToolStripMenuItem;
	}
}

